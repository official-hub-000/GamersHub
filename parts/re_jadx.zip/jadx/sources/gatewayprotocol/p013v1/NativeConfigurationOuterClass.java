package gatewayprotocol.p013v1;

import com.applovin.shadow.okio.Segment;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Parser;
import gatewayprotocol.p013v1.DiagnosticEventRequestOuterClass;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import p000.C0950f;
import p000.fg3;

/* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
/* loaded from: classes2.dex */
public final class NativeConfigurationOuterClass {

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public interface AccelerometerCollectionConfigurationOrBuilder extends MessageLiteOrBuilder {
        int getMaxSamples();

        int getSamplingIntervalMs();
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public interface AdOperationsConfigurationOrBuilder extends MessageLiteOrBuilder {
        int getGetTokenTimeoutMs();

        int getLoadTimeoutMs();

        int getShowTimeoutMs();
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public interface CachedAssetsConfigurationOrBuilder extends MessageLiteOrBuilder {
        long getMaxCachedAssetAgeMs();

        int getMaxCachedAssetSizeMb();
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public interface DebugSettingsOrBuilder extends MessageLiteOrBuilder {
        boolean getCleanCache();

        boolean getEnableTracing();

        boolean getWebviewInspectable();
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public interface DiagnosticEventsConfigurationOrBuilder extends MessageLiteOrBuilder {
        DiagnosticEventRequestOuterClass.DiagnosticEventType getAllowedEvents(int i);

        int getAllowedEventsCount();

        List<DiagnosticEventRequestOuterClass.DiagnosticEventType> getAllowedEventsList();

        int getAllowedEventsValue(int i);

        List<Integer> getAllowedEventsValueList();

        DiagnosticEventRequestOuterClass.DiagnosticEventType getBlockedEvents(int i);

        int getBlockedEventsCount();

        List<DiagnosticEventRequestOuterClass.DiagnosticEventType> getBlockedEventsList();

        int getBlockedEventsValue(int i);

        List<Integer> getBlockedEventsValueList();

        boolean getEnabled();

        int getMaxBatchIntervalMs();

        int getMaxBatchSize();

        DiagnosticEventRequestOuterClass.DiagnosticEventsSeverity getSeverity();

        int getSeverityValue();

        boolean getTtmEnabled();
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public interface FeatureFlagsOrBuilder extends MessageLiteOrBuilder {
        boolean getAppSheetBugCheckEnabled();

        boolean getBoldSdkNextSessionEnabled();

        boolean getCollectAccelerometer();

        boolean getCollectGoogleAppId();

        boolean getCollectIlrData();

        boolean getCollectLifecycleEvents();

        boolean getDisableCustomScheme();

        boolean getDisableGridCollection();

        boolean getEnableCoherenceLibrary();

        boolean getEnsureCacheFolderExistences();

        FullscreenNavBarMode getFullscreenNavBarMode();

        int getFullscreenNavBarModeValue();

        boolean getMeasureBridgePerformance();

        NativeStartMode getNativeStartMode();

        int getNativeStartModeValue();

        boolean getOpenglGpuEnabled();

        boolean getOpportunityIdPlacementValidation();

        PreShowWebViewStrategy getPreShowWebviewStrategy();

        int getPreShowWebviewStrategyValue();

        boolean getRecoverTerminatedWebviews();

        boolean getRetryShowWithCurrentActivity();

        boolean getShouldAllowFetchToAccessCache();

        boolean getShouldHandleWebviewCaching();

        boolean getShouldInitAdqWithGameId();

        boolean getShouldSendIapHistory();

        boolean getUseCurrentActivityForShow();

        boolean getUseFilesDir();

        boolean getUseOptimisticWebviewCache();

        boolean getUseTryCatchInDownloadQueue();

        boolean getWebviewLessLoadParallelActivityLaunch();

        int getWebviewPoolSize();
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public interface NativeConfigurationOrBuilder extends MessageLiteOrBuilder {
        AccelerometerCollectionConfiguration getAccelerometerCollection();

        AdOperationsConfiguration getAdOperations();

        RequestPolicy getAdPolicy();

        String getAdditionalStorePackages(int i);

        ByteString getAdditionalStorePackagesBytes(int i);

        int getAdditionalStorePackagesCount();

        List<String> getAdditionalStorePackagesList();

        CachedAssetsConfiguration getCachedAssetsConfiguration();

        CachedAssetsConfiguration getCachedWebviewFilesConfiguration();

        DebugSettings getDebugSettings();

        ShowCompletionState getDefaultShowCompletionState();

        int getDefaultShowCompletionStateValue();

        DiagnosticEventsConfiguration getDiagnosticEvents();

        RequestPolicy getDownloadPolicy();

        boolean getEnableIapEvent();

        boolean getEnableOm();

        FeatureFlags getFeatureFlags();

        RequestPolicy getInitPolicy();

        String getLevelPlayAppKey();

        ByteString getLevelPlayAppKeyBytes();

        int getMaxExtrasSizeKb();

        int getMaxReceiptSizeMb();

        int getMonitoringIds(int i);

        int getMonitoringIdsCount();

        List<Integer> getMonitoringIdsList();

        ByteString getObservableAndroidActivities(int i);

        int getObservableAndroidActivitiesCount();

        List<ByteString> getObservableAndroidActivitiesList();

        ByteString getObservableViewControllers(int i);

        int getObservableViewControllersCount();

        List<ByteString> getObservableViewControllersList();

        RequestPolicy getOperativeEventPolicy();

        int getOptimisticInitDelayMs();

        RequestPolicy getOtherPolicy();

        int getOverwriteIntentFlagActivity();

        boolean hasAccelerometerCollection();

        boolean hasAdOperations();

        boolean hasAdPolicy();

        boolean hasCachedAssetsConfiguration();

        boolean hasCachedWebviewFilesConfiguration();

        boolean hasDebugSettings();

        boolean hasDiagnosticEvents();

        boolean hasDownloadPolicy();

        boolean hasFeatureFlags();

        boolean hasInitPolicy();

        boolean hasLevelPlayAppKey();

        boolean hasOperativeEventPolicy();

        boolean hasOptimisticInitDelayMs();

        boolean hasOtherPolicy();
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public interface RequestPolicyOrBuilder extends MessageLiteOrBuilder {
        RequestRetryPolicy getRetryPolicy();

        RequestTimeoutPolicy getTimeoutPolicy();

        boolean hasRetryPolicy();

        boolean hasTimeoutPolicy();
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public interface RequestRetryPolicyOrBuilder extends MessageLiteOrBuilder {
        int getMaxDuration();

        float getRetryJitterPct();

        int getRetryMaxInterval();

        float getRetryScalingFactor();

        int getRetryWaitBase();

        boolean getShouldStoreLocally();
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public interface RequestTimeoutPolicyOrBuilder extends MessageLiteOrBuilder {
        int getConnectTimeoutMs();

        int getOverallTimeoutMs();

        int getReadTimeoutMs();

        int getWriteTimeoutMs();
    }

    private NativeConfigurationOuterClass() {
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public static final class AccelerometerCollectionConfiguration extends GeneratedMessageLite<AccelerometerCollectionConfiguration, Builder> implements AccelerometerCollectionConfigurationOrBuilder {
        private static final AccelerometerCollectionConfiguration DEFAULT_INSTANCE;
        public static final int MAX_SAMPLES_FIELD_NUMBER = 2;
        private static volatile Parser<AccelerometerCollectionConfiguration> PARSER = null;
        public static final int SAMPLING_INTERVAL_MS_FIELD_NUMBER = 1;
        private int maxSamples_;
        private int samplingIntervalMs_;

        static {
            AccelerometerCollectionConfiguration accelerometerCollectionConfiguration = new AccelerometerCollectionConfiguration();
            DEFAULT_INSTANCE = accelerometerCollectionConfiguration;
            GeneratedMessageLite.registerDefaultInstance(AccelerometerCollectionConfiguration.class, accelerometerCollectionConfiguration);
        }

        private AccelerometerCollectionConfiguration() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearMaxSamples() {
            this.maxSamples_ = 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearSamplingIntervalMs() {
            this.samplingIntervalMs_ = 0;
        }

        public static AccelerometerCollectionConfiguration getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return DEFAULT_INSTANCE.createBuilder();
        }

        public static AccelerometerCollectionConfiguration parseDelimitedFrom(InputStream inputStream) throws IOException {
            return (AccelerometerCollectionConfiguration) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AccelerometerCollectionConfiguration parseFrom(ByteBuffer byteBuffer) throws InvalidProtocolBufferException {
            return (AccelerometerCollectionConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AccelerometerCollectionConfiguration> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setMaxSamples(int i) {
            this.maxSamples_ = i;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setSamplingIntervalMs(int i) {
            this.samplingIntervalMs_ = i;
        }

        @Override // com.google.protobuf.GeneratedMessageLite
        public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            Parser parser;
            int i = fg3.f13801a[methodToInvoke.ordinal()];
            fg3 fg3Var = null;
            switch (i) {
                case 1:
                    return new AccelerometerCollectionConfiguration();
                case 2:
                    return new Builder(fg3Var);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u0004\u0002\u0004", new Object[]{"samplingIntervalMs_", "maxSamples_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AccelerometerCollectionConfiguration> parser2 = PARSER;
                    if (parser2 != null) {
                        return parser2;
                    }
                    synchronized (AccelerometerCollectionConfiguration.class) {
                        parser = PARSER;
                        if (parser == null) {
                            parser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                            PARSER = parser;
                        }
                    }
                    return parser;
                case 6:
                    return (byte) 1;
                default:
                    C0950f.m10573c();
                case 7:
                    return null;
            }
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.AccelerometerCollectionConfigurationOrBuilder
        public int getMaxSamples() {
            return this.maxSamples_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.AccelerometerCollectionConfigurationOrBuilder
        public int getSamplingIntervalMs() {
            return this.samplingIntervalMs_;
        }

        /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
        public static final class Builder extends GeneratedMessageLite.Builder<AccelerometerCollectionConfiguration, Builder> implements AccelerometerCollectionConfigurationOrBuilder {
            private Builder() {
                super(AccelerometerCollectionConfiguration.DEFAULT_INSTANCE);
            }

            public Builder clearMaxSamples() {
                copyOnWrite();
                ((AccelerometerCollectionConfiguration) this.instance).clearMaxSamples();
                return this;
            }

            public Builder clearSamplingIntervalMs() {
                copyOnWrite();
                ((AccelerometerCollectionConfiguration) this.instance).clearSamplingIntervalMs();
                return this;
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.AccelerometerCollectionConfigurationOrBuilder
            public int getMaxSamples() {
                return ((AccelerometerCollectionConfiguration) this.instance).getMaxSamples();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.AccelerometerCollectionConfigurationOrBuilder
            public int getSamplingIntervalMs() {
                return ((AccelerometerCollectionConfiguration) this.instance).getSamplingIntervalMs();
            }

            public Builder setMaxSamples(int i) {
                copyOnWrite();
                ((AccelerometerCollectionConfiguration) this.instance).setMaxSamples(i);
                return this;
            }

            public Builder setSamplingIntervalMs(int i) {
                copyOnWrite();
                ((AccelerometerCollectionConfiguration) this.instance).setSamplingIntervalMs(i);
                return this;
            }

            public /* synthetic */ Builder(fg3 fg3Var) {
                this();
            }
        }

        public static Builder newBuilder(AccelerometerCollectionConfiguration accelerometerCollectionConfiguration) {
            return DEFAULT_INSTANCE.createBuilder(accelerometerCollectionConfiguration);
        }

        public static AccelerometerCollectionConfiguration parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (AccelerometerCollectionConfiguration) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AccelerometerCollectionConfiguration parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (AccelerometerCollectionConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AccelerometerCollectionConfiguration parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return (AccelerometerCollectionConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static AccelerometerCollectionConfiguration parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (AccelerometerCollectionConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AccelerometerCollectionConfiguration parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return (AccelerometerCollectionConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AccelerometerCollectionConfiguration parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (AccelerometerCollectionConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AccelerometerCollectionConfiguration parseFrom(InputStream inputStream) throws IOException {
            return (AccelerometerCollectionConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AccelerometerCollectionConfiguration parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (AccelerometerCollectionConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AccelerometerCollectionConfiguration parseFrom(CodedInputStream codedInputStream) throws IOException {
            return (AccelerometerCollectionConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AccelerometerCollectionConfiguration parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (AccelerometerCollectionConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public static final class AdOperationsConfiguration extends GeneratedMessageLite<AdOperationsConfiguration, Builder> implements AdOperationsConfigurationOrBuilder {
        private static final AdOperationsConfiguration DEFAULT_INSTANCE;
        public static final int GET_TOKEN_TIMEOUT_MS_FIELD_NUMBER = 3;
        public static final int LOAD_TIMEOUT_MS_FIELD_NUMBER = 1;
        private static volatile Parser<AdOperationsConfiguration> PARSER = null;
        public static final int SHOW_TIMEOUT_MS_FIELD_NUMBER = 2;
        private int getTokenTimeoutMs_;
        private int loadTimeoutMs_;
        private int showTimeoutMs_;

        static {
            AdOperationsConfiguration adOperationsConfiguration = new AdOperationsConfiguration();
            DEFAULT_INSTANCE = adOperationsConfiguration;
            GeneratedMessageLite.registerDefaultInstance(AdOperationsConfiguration.class, adOperationsConfiguration);
        }

        private AdOperationsConfiguration() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearGetTokenTimeoutMs() {
            this.getTokenTimeoutMs_ = 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearLoadTimeoutMs() {
            this.loadTimeoutMs_ = 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearShowTimeoutMs() {
            this.showTimeoutMs_ = 0;
        }

        public static AdOperationsConfiguration getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return DEFAULT_INSTANCE.createBuilder();
        }

        public static AdOperationsConfiguration parseDelimitedFrom(InputStream inputStream) throws IOException {
            return (AdOperationsConfiguration) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AdOperationsConfiguration parseFrom(ByteBuffer byteBuffer) throws InvalidProtocolBufferException {
            return (AdOperationsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AdOperationsConfiguration> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setGetTokenTimeoutMs(int i) {
            this.getTokenTimeoutMs_ = i;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setLoadTimeoutMs(int i) {
            this.loadTimeoutMs_ = i;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setShowTimeoutMs(int i) {
            this.showTimeoutMs_ = i;
        }

        @Override // com.google.protobuf.GeneratedMessageLite
        public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            Parser parser;
            int i = fg3.f13801a[methodToInvoke.ordinal()];
            fg3 fg3Var = null;
            switch (i) {
                case 1:
                    return new AdOperationsConfiguration();
                case 2:
                    return new Builder(fg3Var);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u0004\u0002\u0004\u0003\u0004", new Object[]{"loadTimeoutMs_", "showTimeoutMs_", "getTokenTimeoutMs_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AdOperationsConfiguration> parser2 = PARSER;
                    if (parser2 != null) {
                        return parser2;
                    }
                    synchronized (AdOperationsConfiguration.class) {
                        parser = PARSER;
                        if (parser == null) {
                            parser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                            PARSER = parser;
                        }
                    }
                    return parser;
                case 6:
                    return (byte) 1;
                default:
                    C0950f.m10573c();
                case 7:
                    return null;
            }
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.AdOperationsConfigurationOrBuilder
        public int getGetTokenTimeoutMs() {
            return this.getTokenTimeoutMs_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.AdOperationsConfigurationOrBuilder
        public int getLoadTimeoutMs() {
            return this.loadTimeoutMs_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.AdOperationsConfigurationOrBuilder
        public int getShowTimeoutMs() {
            return this.showTimeoutMs_;
        }

        /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
        public static final class Builder extends GeneratedMessageLite.Builder<AdOperationsConfiguration, Builder> implements AdOperationsConfigurationOrBuilder {
            private Builder() {
                super(AdOperationsConfiguration.DEFAULT_INSTANCE);
            }

            public Builder clearGetTokenTimeoutMs() {
                copyOnWrite();
                ((AdOperationsConfiguration) this.instance).clearGetTokenTimeoutMs();
                return this;
            }

            public Builder clearLoadTimeoutMs() {
                copyOnWrite();
                ((AdOperationsConfiguration) this.instance).clearLoadTimeoutMs();
                return this;
            }

            public Builder clearShowTimeoutMs() {
                copyOnWrite();
                ((AdOperationsConfiguration) this.instance).clearShowTimeoutMs();
                return this;
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.AdOperationsConfigurationOrBuilder
            public int getGetTokenTimeoutMs() {
                return ((AdOperationsConfiguration) this.instance).getGetTokenTimeoutMs();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.AdOperationsConfigurationOrBuilder
            public int getLoadTimeoutMs() {
                return ((AdOperationsConfiguration) this.instance).getLoadTimeoutMs();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.AdOperationsConfigurationOrBuilder
            public int getShowTimeoutMs() {
                return ((AdOperationsConfiguration) this.instance).getShowTimeoutMs();
            }

            public Builder setGetTokenTimeoutMs(int i) {
                copyOnWrite();
                ((AdOperationsConfiguration) this.instance).setGetTokenTimeoutMs(i);
                return this;
            }

            public Builder setLoadTimeoutMs(int i) {
                copyOnWrite();
                ((AdOperationsConfiguration) this.instance).setLoadTimeoutMs(i);
                return this;
            }

            public Builder setShowTimeoutMs(int i) {
                copyOnWrite();
                ((AdOperationsConfiguration) this.instance).setShowTimeoutMs(i);
                return this;
            }

            public /* synthetic */ Builder(fg3 fg3Var) {
                this();
            }
        }

        public static Builder newBuilder(AdOperationsConfiguration adOperationsConfiguration) {
            return DEFAULT_INSTANCE.createBuilder(adOperationsConfiguration);
        }

        public static AdOperationsConfiguration parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (AdOperationsConfiguration) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AdOperationsConfiguration parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (AdOperationsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AdOperationsConfiguration parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return (AdOperationsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static AdOperationsConfiguration parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (AdOperationsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AdOperationsConfiguration parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return (AdOperationsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AdOperationsConfiguration parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (AdOperationsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AdOperationsConfiguration parseFrom(InputStream inputStream) throws IOException {
            return (AdOperationsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AdOperationsConfiguration parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (AdOperationsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AdOperationsConfiguration parseFrom(CodedInputStream codedInputStream) throws IOException {
            return (AdOperationsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AdOperationsConfiguration parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (AdOperationsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public static final class CachedAssetsConfiguration extends GeneratedMessageLite<CachedAssetsConfiguration, Builder> implements CachedAssetsConfigurationOrBuilder {
        private static final CachedAssetsConfiguration DEFAULT_INSTANCE;
        public static final int MAX_CACHED_ASSET_AGE_MS_FIELD_NUMBER = 1;
        public static final int MAX_CACHED_ASSET_SIZE_MB_FIELD_NUMBER = 2;
        private static volatile Parser<CachedAssetsConfiguration> PARSER;
        private long maxCachedAssetAgeMs_;
        private int maxCachedAssetSizeMb_;

        static {
            CachedAssetsConfiguration cachedAssetsConfiguration = new CachedAssetsConfiguration();
            DEFAULT_INSTANCE = cachedAssetsConfiguration;
            GeneratedMessageLite.registerDefaultInstance(CachedAssetsConfiguration.class, cachedAssetsConfiguration);
        }

        private CachedAssetsConfiguration() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearMaxCachedAssetAgeMs() {
            this.maxCachedAssetAgeMs_ = 0L;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearMaxCachedAssetSizeMb() {
            this.maxCachedAssetSizeMb_ = 0;
        }

        public static CachedAssetsConfiguration getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return DEFAULT_INSTANCE.createBuilder();
        }

        public static CachedAssetsConfiguration parseDelimitedFrom(InputStream inputStream) throws IOException {
            return (CachedAssetsConfiguration) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CachedAssetsConfiguration parseFrom(ByteBuffer byteBuffer) throws InvalidProtocolBufferException {
            return (CachedAssetsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<CachedAssetsConfiguration> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setMaxCachedAssetAgeMs(long j) {
            this.maxCachedAssetAgeMs_ = j;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setMaxCachedAssetSizeMb(int i) {
            this.maxCachedAssetSizeMb_ = i;
        }

        @Override // com.google.protobuf.GeneratedMessageLite
        public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            Parser parser;
            int i = fg3.f13801a[methodToInvoke.ordinal()];
            fg3 fg3Var = null;
            switch (i) {
                case 1:
                    return new CachedAssetsConfiguration();
                case 2:
                    return new Builder(fg3Var);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u0002\u0002\u0004", new Object[]{"maxCachedAssetAgeMs_", "maxCachedAssetSizeMb_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<CachedAssetsConfiguration> parser2 = PARSER;
                    if (parser2 != null) {
                        return parser2;
                    }
                    synchronized (CachedAssetsConfiguration.class) {
                        parser = PARSER;
                        if (parser == null) {
                            parser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                            PARSER = parser;
                        }
                    }
                    return parser;
                case 6:
                    return (byte) 1;
                default:
                    C0950f.m10573c();
                case 7:
                    return null;
            }
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.CachedAssetsConfigurationOrBuilder
        public long getMaxCachedAssetAgeMs() {
            return this.maxCachedAssetAgeMs_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.CachedAssetsConfigurationOrBuilder
        public int getMaxCachedAssetSizeMb() {
            return this.maxCachedAssetSizeMb_;
        }

        /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
        public static final class Builder extends GeneratedMessageLite.Builder<CachedAssetsConfiguration, Builder> implements CachedAssetsConfigurationOrBuilder {
            private Builder() {
                super(CachedAssetsConfiguration.DEFAULT_INSTANCE);
            }

            public Builder clearMaxCachedAssetAgeMs() {
                copyOnWrite();
                ((CachedAssetsConfiguration) this.instance).clearMaxCachedAssetAgeMs();
                return this;
            }

            public Builder clearMaxCachedAssetSizeMb() {
                copyOnWrite();
                ((CachedAssetsConfiguration) this.instance).clearMaxCachedAssetSizeMb();
                return this;
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.CachedAssetsConfigurationOrBuilder
            public long getMaxCachedAssetAgeMs() {
                return ((CachedAssetsConfiguration) this.instance).getMaxCachedAssetAgeMs();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.CachedAssetsConfigurationOrBuilder
            public int getMaxCachedAssetSizeMb() {
                return ((CachedAssetsConfiguration) this.instance).getMaxCachedAssetSizeMb();
            }

            public Builder setMaxCachedAssetAgeMs(long j) {
                copyOnWrite();
                ((CachedAssetsConfiguration) this.instance).setMaxCachedAssetAgeMs(j);
                return this;
            }

            public Builder setMaxCachedAssetSizeMb(int i) {
                copyOnWrite();
                ((CachedAssetsConfiguration) this.instance).setMaxCachedAssetSizeMb(i);
                return this;
            }

            public /* synthetic */ Builder(fg3 fg3Var) {
                this();
            }
        }

        public static Builder newBuilder(CachedAssetsConfiguration cachedAssetsConfiguration) {
            return DEFAULT_INSTANCE.createBuilder(cachedAssetsConfiguration);
        }

        public static CachedAssetsConfiguration parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (CachedAssetsConfiguration) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CachedAssetsConfiguration parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (CachedAssetsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static CachedAssetsConfiguration parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return (CachedAssetsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static CachedAssetsConfiguration parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (CachedAssetsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static CachedAssetsConfiguration parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return (CachedAssetsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static CachedAssetsConfiguration parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (CachedAssetsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static CachedAssetsConfiguration parseFrom(InputStream inputStream) throws IOException {
            return (CachedAssetsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CachedAssetsConfiguration parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (CachedAssetsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CachedAssetsConfiguration parseFrom(CodedInputStream codedInputStream) throws IOException {
            return (CachedAssetsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static CachedAssetsConfiguration parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (CachedAssetsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public static final class DebugSettings extends GeneratedMessageLite<DebugSettings, Builder> implements DebugSettingsOrBuilder {
        public static final int CLEAN_CACHE_FIELD_NUMBER = 3;
        private static final DebugSettings DEFAULT_INSTANCE;
        public static final int ENABLE_TRACING_FIELD_NUMBER = 2;
        private static volatile Parser<DebugSettings> PARSER = null;
        public static final int WEBVIEW_INSPECTABLE_FIELD_NUMBER = 1;
        private boolean cleanCache_;
        private boolean enableTracing_;
        private boolean webviewInspectable_;

        static {
            DebugSettings debugSettings = new DebugSettings();
            DEFAULT_INSTANCE = debugSettings;
            GeneratedMessageLite.registerDefaultInstance(DebugSettings.class, debugSettings);
        }

        private DebugSettings() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearCleanCache() {
            this.cleanCache_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearEnableTracing() {
            this.enableTracing_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearWebviewInspectable() {
            this.webviewInspectable_ = false;
        }

        public static DebugSettings getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return DEFAULT_INSTANCE.createBuilder();
        }

        public static DebugSettings parseDelimitedFrom(InputStream inputStream) throws IOException {
            return (DebugSettings) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DebugSettings parseFrom(ByteBuffer byteBuffer) throws InvalidProtocolBufferException {
            return (DebugSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<DebugSettings> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setCleanCache(boolean z) {
            this.cleanCache_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setEnableTracing(boolean z) {
            this.enableTracing_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setWebviewInspectable(boolean z) {
            this.webviewInspectable_ = z;
        }

        @Override // com.google.protobuf.GeneratedMessageLite
        public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            Parser parser;
            int i = fg3.f13801a[methodToInvoke.ordinal()];
            fg3 fg3Var = null;
            switch (i) {
                case 1:
                    return new DebugSettings();
                case 2:
                    return new Builder(fg3Var);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u0007\u0002\u0007\u0003\u0007", new Object[]{"webviewInspectable_", "enableTracing_", "cleanCache_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<DebugSettings> parser2 = PARSER;
                    if (parser2 != null) {
                        return parser2;
                    }
                    synchronized (DebugSettings.class) {
                        parser = PARSER;
                        if (parser == null) {
                            parser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                            PARSER = parser;
                        }
                    }
                    return parser;
                case 6:
                    return (byte) 1;
                default:
                    C0950f.m10573c();
                case 7:
                    return null;
            }
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DebugSettingsOrBuilder
        public boolean getCleanCache() {
            return this.cleanCache_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DebugSettingsOrBuilder
        public boolean getEnableTracing() {
            return this.enableTracing_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DebugSettingsOrBuilder
        public boolean getWebviewInspectable() {
            return this.webviewInspectable_;
        }

        /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
        public static final class Builder extends GeneratedMessageLite.Builder<DebugSettings, Builder> implements DebugSettingsOrBuilder {
            private Builder() {
                super(DebugSettings.DEFAULT_INSTANCE);
            }

            public Builder clearCleanCache() {
                copyOnWrite();
                ((DebugSettings) this.instance).clearCleanCache();
                return this;
            }

            public Builder clearEnableTracing() {
                copyOnWrite();
                ((DebugSettings) this.instance).clearEnableTracing();
                return this;
            }

            public Builder clearWebviewInspectable() {
                copyOnWrite();
                ((DebugSettings) this.instance).clearWebviewInspectable();
                return this;
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DebugSettingsOrBuilder
            public boolean getCleanCache() {
                return ((DebugSettings) this.instance).getCleanCache();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DebugSettingsOrBuilder
            public boolean getEnableTracing() {
                return ((DebugSettings) this.instance).getEnableTracing();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DebugSettingsOrBuilder
            public boolean getWebviewInspectable() {
                return ((DebugSettings) this.instance).getWebviewInspectable();
            }

            public Builder setCleanCache(boolean z) {
                copyOnWrite();
                ((DebugSettings) this.instance).setCleanCache(z);
                return this;
            }

            public Builder setEnableTracing(boolean z) {
                copyOnWrite();
                ((DebugSettings) this.instance).setEnableTracing(z);
                return this;
            }

            public Builder setWebviewInspectable(boolean z) {
                copyOnWrite();
                ((DebugSettings) this.instance).setWebviewInspectable(z);
                return this;
            }

            public /* synthetic */ Builder(fg3 fg3Var) {
                this();
            }
        }

        public static Builder newBuilder(DebugSettings debugSettings) {
            return DEFAULT_INSTANCE.createBuilder(debugSettings);
        }

        public static DebugSettings parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (DebugSettings) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DebugSettings parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (DebugSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static DebugSettings parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return (DebugSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static DebugSettings parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (DebugSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static DebugSettings parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return (DebugSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static DebugSettings parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (DebugSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static DebugSettings parseFrom(InputStream inputStream) throws IOException {
            return (DebugSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DebugSettings parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (DebugSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DebugSettings parseFrom(CodedInputStream codedInputStream) throws IOException {
            return (DebugSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static DebugSettings parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (DebugSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public static final class DiagnosticEventsConfiguration extends GeneratedMessageLite<DiagnosticEventsConfiguration, Builder> implements DiagnosticEventsConfigurationOrBuilder {
        public static final int ALLOWED_EVENTS_FIELD_NUMBER = 6;
        public static final int BLOCKED_EVENTS_FIELD_NUMBER = 7;
        private static final DiagnosticEventsConfiguration DEFAULT_INSTANCE;
        public static final int ENABLED_FIELD_NUMBER = 1;
        public static final int MAX_BATCH_INTERVAL_MS_FIELD_NUMBER = 3;
        public static final int MAX_BATCH_SIZE_FIELD_NUMBER = 2;
        private static volatile Parser<DiagnosticEventsConfiguration> PARSER = null;
        public static final int SEVERITY_FIELD_NUMBER = 5;
        public static final int TTM_ENABLED_FIELD_NUMBER = 4;
        private static final Internal.ListAdapter.Converter<Integer, DiagnosticEventRequestOuterClass.DiagnosticEventType> allowedEvents_converter_ = new C1048p0();
        private static final Internal.ListAdapter.Converter<Integer, DiagnosticEventRequestOuterClass.DiagnosticEventType> blockedEvents_converter_ = new C1050q0();
        private int allowedEventsMemoizedSerializedSize;
        private int blockedEventsMemoizedSerializedSize;
        private boolean enabled_;
        private int maxBatchIntervalMs_;
        private int maxBatchSize_;
        private int severity_;
        private boolean ttmEnabled_;
        private Internal.IntList allowedEvents_ = GeneratedMessageLite.emptyIntList();
        private Internal.IntList blockedEvents_ = GeneratedMessageLite.emptyIntList();

        static {
            DiagnosticEventsConfiguration diagnosticEventsConfiguration = new DiagnosticEventsConfiguration();
            DEFAULT_INSTANCE = diagnosticEventsConfiguration;
            GeneratedMessageLite.registerDefaultInstance(DiagnosticEventsConfiguration.class, diagnosticEventsConfiguration);
        }

        private DiagnosticEventsConfiguration() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void addAllAllowedEvents(Iterable<? extends DiagnosticEventRequestOuterClass.DiagnosticEventType> iterable) {
            ensureAllowedEventsIsMutable();
            Iterator<? extends DiagnosticEventRequestOuterClass.DiagnosticEventType> it = iterable.iterator();
            while (it.hasNext()) {
                this.allowedEvents_.addInt(it.next().getNumber());
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void addAllAllowedEventsValue(Iterable<Integer> iterable) {
            ensureAllowedEventsIsMutable();
            Iterator<Integer> it = iterable.iterator();
            while (it.hasNext()) {
                this.allowedEvents_.addInt(it.next().intValue());
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void addAllBlockedEvents(Iterable<? extends DiagnosticEventRequestOuterClass.DiagnosticEventType> iterable) {
            ensureBlockedEventsIsMutable();
            Iterator<? extends DiagnosticEventRequestOuterClass.DiagnosticEventType> it = iterable.iterator();
            while (it.hasNext()) {
                this.blockedEvents_.addInt(it.next().getNumber());
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void addAllBlockedEventsValue(Iterable<Integer> iterable) {
            ensureBlockedEventsIsMutable();
            Iterator<Integer> it = iterable.iterator();
            while (it.hasNext()) {
                this.blockedEvents_.addInt(it.next().intValue());
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void addAllowedEvents(DiagnosticEventRequestOuterClass.DiagnosticEventType diagnosticEventType) {
            diagnosticEventType.getClass();
            ensureAllowedEventsIsMutable();
            this.allowedEvents_.addInt(diagnosticEventType.getNumber());
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void addAllowedEventsValue(int i) {
            ensureAllowedEventsIsMutable();
            this.allowedEvents_.addInt(i);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void addBlockedEvents(DiagnosticEventRequestOuterClass.DiagnosticEventType diagnosticEventType) {
            diagnosticEventType.getClass();
            ensureBlockedEventsIsMutable();
            this.blockedEvents_.addInt(diagnosticEventType.getNumber());
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void addBlockedEventsValue(int i) {
            ensureBlockedEventsIsMutable();
            this.blockedEvents_.addInt(i);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearAllowedEvents() {
            this.allowedEvents_ = GeneratedMessageLite.emptyIntList();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearBlockedEvents() {
            this.blockedEvents_ = GeneratedMessageLite.emptyIntList();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearEnabled() {
            this.enabled_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearMaxBatchIntervalMs() {
            this.maxBatchIntervalMs_ = 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearMaxBatchSize() {
            this.maxBatchSize_ = 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearSeverity() {
            this.severity_ = 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearTtmEnabled() {
            this.ttmEnabled_ = false;
        }

        private void ensureAllowedEventsIsMutable() {
            Internal.IntList intList = this.allowedEvents_;
            if (intList.isModifiable()) {
                return;
            }
            this.allowedEvents_ = GeneratedMessageLite.mutableCopy(intList);
        }

        private void ensureBlockedEventsIsMutable() {
            Internal.IntList intList = this.blockedEvents_;
            if (intList.isModifiable()) {
                return;
            }
            this.blockedEvents_ = GeneratedMessageLite.mutableCopy(intList);
        }

        public static DiagnosticEventsConfiguration getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return DEFAULT_INSTANCE.createBuilder();
        }

        public static DiagnosticEventsConfiguration parseDelimitedFrom(InputStream inputStream) throws IOException {
            return (DiagnosticEventsConfiguration) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DiagnosticEventsConfiguration parseFrom(ByteBuffer byteBuffer) throws InvalidProtocolBufferException {
            return (DiagnosticEventsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<DiagnosticEventsConfiguration> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setAllowedEvents(int i, DiagnosticEventRequestOuterClass.DiagnosticEventType diagnosticEventType) {
            diagnosticEventType.getClass();
            ensureAllowedEventsIsMutable();
            this.allowedEvents_.setInt(i, diagnosticEventType.getNumber());
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setAllowedEventsValue(int i, int i2) {
            ensureAllowedEventsIsMutable();
            this.allowedEvents_.setInt(i, i2);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setBlockedEvents(int i, DiagnosticEventRequestOuterClass.DiagnosticEventType diagnosticEventType) {
            diagnosticEventType.getClass();
            ensureBlockedEventsIsMutable();
            this.blockedEvents_.setInt(i, diagnosticEventType.getNumber());
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setBlockedEventsValue(int i, int i2) {
            ensureBlockedEventsIsMutable();
            this.blockedEvents_.setInt(i, i2);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setEnabled(boolean z) {
            this.enabled_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setMaxBatchIntervalMs(int i) {
            this.maxBatchIntervalMs_ = i;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setMaxBatchSize(int i) {
            this.maxBatchSize_ = i;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setSeverity(DiagnosticEventRequestOuterClass.DiagnosticEventsSeverity diagnosticEventsSeverity) {
            this.severity_ = diagnosticEventsSeverity.getNumber();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setSeverityValue(int i) {
            this.severity_ = i;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setTtmEnabled(boolean z) {
            this.ttmEnabled_ = z;
        }

        @Override // com.google.protobuf.GeneratedMessageLite
        public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            Parser parser;
            int i = fg3.f13801a[methodToInvoke.ordinal()];
            fg3 fg3Var = null;
            switch (i) {
                case 1:
                    return new DiagnosticEventsConfiguration();
                case 2:
                    return new Builder(fg3Var);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0007\u0000\u0000\u0001\u0007\u0007\u0000\u0002\u0000\u0001\u0007\u0002\u0004\u0003\u0004\u0004\u0007\u0005\f\u0006,\u0007,", new Object[]{"enabled_", "maxBatchSize_", "maxBatchIntervalMs_", "ttmEnabled_", "severity_", "allowedEvents_", "blockedEvents_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<DiagnosticEventsConfiguration> parser2 = PARSER;
                    if (parser2 != null) {
                        return parser2;
                    }
                    synchronized (DiagnosticEventsConfiguration.class) {
                        parser = PARSER;
                        if (parser == null) {
                            parser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                            PARSER = parser;
                        }
                    }
                    return parser;
                case 6:
                    return (byte) 1;
                default:
                    C0950f.m10573c();
                case 7:
                    return null;
            }
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
        public DiagnosticEventRequestOuterClass.DiagnosticEventType getAllowedEvents(int i) {
            DiagnosticEventRequestOuterClass.DiagnosticEventType forNumber = DiagnosticEventRequestOuterClass.DiagnosticEventType.forNumber(this.allowedEvents_.getInt(i));
            return forNumber == null ? DiagnosticEventRequestOuterClass.DiagnosticEventType.UNRECOGNIZED : forNumber;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
        public int getAllowedEventsCount() {
            return this.allowedEvents_.size();
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
        public List<DiagnosticEventRequestOuterClass.DiagnosticEventType> getAllowedEventsList() {
            return new Internal.ListAdapter(this.allowedEvents_, allowedEvents_converter_);
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
        public int getAllowedEventsValue(int i) {
            return this.allowedEvents_.getInt(i);
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
        public List<Integer> getAllowedEventsValueList() {
            return this.allowedEvents_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
        public DiagnosticEventRequestOuterClass.DiagnosticEventType getBlockedEvents(int i) {
            DiagnosticEventRequestOuterClass.DiagnosticEventType forNumber = DiagnosticEventRequestOuterClass.DiagnosticEventType.forNumber(this.blockedEvents_.getInt(i));
            return forNumber == null ? DiagnosticEventRequestOuterClass.DiagnosticEventType.UNRECOGNIZED : forNumber;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
        public int getBlockedEventsCount() {
            return this.blockedEvents_.size();
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
        public List<DiagnosticEventRequestOuterClass.DiagnosticEventType> getBlockedEventsList() {
            return new Internal.ListAdapter(this.blockedEvents_, blockedEvents_converter_);
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
        public int getBlockedEventsValue(int i) {
            return this.blockedEvents_.getInt(i);
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
        public List<Integer> getBlockedEventsValueList() {
            return this.blockedEvents_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
        public boolean getEnabled() {
            return this.enabled_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
        public int getMaxBatchIntervalMs() {
            return this.maxBatchIntervalMs_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
        public int getMaxBatchSize() {
            return this.maxBatchSize_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
        public DiagnosticEventRequestOuterClass.DiagnosticEventsSeverity getSeverity() {
            DiagnosticEventRequestOuterClass.DiagnosticEventsSeverity forNumber = DiagnosticEventRequestOuterClass.DiagnosticEventsSeverity.forNumber(this.severity_);
            return forNumber == null ? DiagnosticEventRequestOuterClass.DiagnosticEventsSeverity.UNRECOGNIZED : forNumber;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
        public int getSeverityValue() {
            return this.severity_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
        public boolean getTtmEnabled() {
            return this.ttmEnabled_;
        }

        /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
        public static final class Builder extends GeneratedMessageLite.Builder<DiagnosticEventsConfiguration, Builder> implements DiagnosticEventsConfigurationOrBuilder {
            private Builder() {
                super(DiagnosticEventsConfiguration.DEFAULT_INSTANCE);
            }

            public Builder addAllAllowedEvents(Iterable<? extends DiagnosticEventRequestOuterClass.DiagnosticEventType> iterable) {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).addAllAllowedEvents(iterable);
                return this;
            }

            public Builder addAllAllowedEventsValue(Iterable<Integer> iterable) {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).addAllAllowedEventsValue(iterable);
                return this;
            }

            public Builder addAllBlockedEvents(Iterable<? extends DiagnosticEventRequestOuterClass.DiagnosticEventType> iterable) {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).addAllBlockedEvents(iterable);
                return this;
            }

            public Builder addAllBlockedEventsValue(Iterable<Integer> iterable) {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).addAllBlockedEventsValue(iterable);
                return this;
            }

            public Builder addAllowedEvents(DiagnosticEventRequestOuterClass.DiagnosticEventType diagnosticEventType) {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).addAllowedEvents(diagnosticEventType);
                return this;
            }

            public Builder addAllowedEventsValue(int i) {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).addAllowedEventsValue(i);
                return this;
            }

            public Builder addBlockedEvents(DiagnosticEventRequestOuterClass.DiagnosticEventType diagnosticEventType) {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).addBlockedEvents(diagnosticEventType);
                return this;
            }

            public Builder addBlockedEventsValue(int i) {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).addBlockedEventsValue(i);
                return this;
            }

            public Builder clearAllowedEvents() {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).clearAllowedEvents();
                return this;
            }

            public Builder clearBlockedEvents() {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).clearBlockedEvents();
                return this;
            }

            public Builder clearEnabled() {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).clearEnabled();
                return this;
            }

            public Builder clearMaxBatchIntervalMs() {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).clearMaxBatchIntervalMs();
                return this;
            }

            public Builder clearMaxBatchSize() {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).clearMaxBatchSize();
                return this;
            }

            public Builder clearSeverity() {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).clearSeverity();
                return this;
            }

            public Builder clearTtmEnabled() {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).clearTtmEnabled();
                return this;
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
            public DiagnosticEventRequestOuterClass.DiagnosticEventType getAllowedEvents(int i) {
                return ((DiagnosticEventsConfiguration) this.instance).getAllowedEvents(i);
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
            public int getAllowedEventsCount() {
                return ((DiagnosticEventsConfiguration) this.instance).getAllowedEventsCount();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
            public List<DiagnosticEventRequestOuterClass.DiagnosticEventType> getAllowedEventsList() {
                return ((DiagnosticEventsConfiguration) this.instance).getAllowedEventsList();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
            public int getAllowedEventsValue(int i) {
                return ((DiagnosticEventsConfiguration) this.instance).getAllowedEventsValue(i);
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
            public List<Integer> getAllowedEventsValueList() {
                return Collections.unmodifiableList(((DiagnosticEventsConfiguration) this.instance).getAllowedEventsValueList());
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
            public DiagnosticEventRequestOuterClass.DiagnosticEventType getBlockedEvents(int i) {
                return ((DiagnosticEventsConfiguration) this.instance).getBlockedEvents(i);
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
            public int getBlockedEventsCount() {
                return ((DiagnosticEventsConfiguration) this.instance).getBlockedEventsCount();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
            public List<DiagnosticEventRequestOuterClass.DiagnosticEventType> getBlockedEventsList() {
                return ((DiagnosticEventsConfiguration) this.instance).getBlockedEventsList();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
            public int getBlockedEventsValue(int i) {
                return ((DiagnosticEventsConfiguration) this.instance).getBlockedEventsValue(i);
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
            public List<Integer> getBlockedEventsValueList() {
                return Collections.unmodifiableList(((DiagnosticEventsConfiguration) this.instance).getBlockedEventsValueList());
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
            public boolean getEnabled() {
                return ((DiagnosticEventsConfiguration) this.instance).getEnabled();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
            public int getMaxBatchIntervalMs() {
                return ((DiagnosticEventsConfiguration) this.instance).getMaxBatchIntervalMs();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
            public int getMaxBatchSize() {
                return ((DiagnosticEventsConfiguration) this.instance).getMaxBatchSize();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
            public DiagnosticEventRequestOuterClass.DiagnosticEventsSeverity getSeverity() {
                return ((DiagnosticEventsConfiguration) this.instance).getSeverity();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
            public int getSeverityValue() {
                return ((DiagnosticEventsConfiguration) this.instance).getSeverityValue();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.DiagnosticEventsConfigurationOrBuilder
            public boolean getTtmEnabled() {
                return ((DiagnosticEventsConfiguration) this.instance).getTtmEnabled();
            }

            public Builder setAllowedEvents(int i, DiagnosticEventRequestOuterClass.DiagnosticEventType diagnosticEventType) {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).setAllowedEvents(i, diagnosticEventType);
                return this;
            }

            public Builder setAllowedEventsValue(int i, int i2) {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).setAllowedEventsValue(i, i2);
                return this;
            }

            public Builder setBlockedEvents(int i, DiagnosticEventRequestOuterClass.DiagnosticEventType diagnosticEventType) {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).setBlockedEvents(i, diagnosticEventType);
                return this;
            }

            public Builder setBlockedEventsValue(int i, int i2) {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).setBlockedEventsValue(i, i2);
                return this;
            }

            public Builder setEnabled(boolean z) {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).setEnabled(z);
                return this;
            }

            public Builder setMaxBatchIntervalMs(int i) {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).setMaxBatchIntervalMs(i);
                return this;
            }

            public Builder setMaxBatchSize(int i) {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).setMaxBatchSize(i);
                return this;
            }

            public Builder setSeverity(DiagnosticEventRequestOuterClass.DiagnosticEventsSeverity diagnosticEventsSeverity) {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).setSeverity(diagnosticEventsSeverity);
                return this;
            }

            public Builder setSeverityValue(int i) {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).setSeverityValue(i);
                return this;
            }

            public Builder setTtmEnabled(boolean z) {
                copyOnWrite();
                ((DiagnosticEventsConfiguration) this.instance).setTtmEnabled(z);
                return this;
            }

            public /* synthetic */ Builder(fg3 fg3Var) {
                this();
            }
        }

        public static Builder newBuilder(DiagnosticEventsConfiguration diagnosticEventsConfiguration) {
            return DEFAULT_INSTANCE.createBuilder(diagnosticEventsConfiguration);
        }

        public static DiagnosticEventsConfiguration parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (DiagnosticEventsConfiguration) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DiagnosticEventsConfiguration parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (DiagnosticEventsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static DiagnosticEventsConfiguration parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return (DiagnosticEventsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static DiagnosticEventsConfiguration parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (DiagnosticEventsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static DiagnosticEventsConfiguration parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return (DiagnosticEventsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static DiagnosticEventsConfiguration parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (DiagnosticEventsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static DiagnosticEventsConfiguration parseFrom(InputStream inputStream) throws IOException {
            return (DiagnosticEventsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DiagnosticEventsConfiguration parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (DiagnosticEventsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DiagnosticEventsConfiguration parseFrom(CodedInputStream codedInputStream) throws IOException {
            return (DiagnosticEventsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static DiagnosticEventsConfiguration parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (DiagnosticEventsConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public static final class FeatureFlags extends GeneratedMessageLite<FeatureFlags, Builder> implements FeatureFlagsOrBuilder {
        public static final int APP_SHEET_BUG_CHECK_ENABLED_FIELD_NUMBER = 4;
        public static final int BOLD_SDK_NEXT_SESSION_ENABLED_FIELD_NUMBER = 3;
        public static final int COLLECT_ACCELEROMETER_FIELD_NUMBER = 22;
        public static final int COLLECT_GOOGLE_APP_ID_FIELD_NUMBER = 18;
        public static final int COLLECT_ILR_DATA_FIELD_NUMBER = 8;
        public static final int COLLECT_LIFECYCLE_EVENTS_FIELD_NUMBER = 15;
        private static final FeatureFlags DEFAULT_INSTANCE;
        public static final int DISABLE_CUSTOM_SCHEME_FIELD_NUMBER = 10;
        public static final int DISABLE_GRID_COLLECTION_FIELD_NUMBER = 9;
        public static final int ENABLE_COHERENCE_LIBRARY_FIELD_NUMBER = 19;
        public static final int ENSURE_CACHE_FOLDER_EXISTENCES_FIELD_NUMBER = 13;
        public static final int FULLSCREEN_NAV_BAR_MODE_FIELD_NUMBER = 20;
        public static final int MEASURE_BRIDGE_PERFORMANCE_FIELD_NUMBER = 24;
        public static final int NATIVE_START_MODE_FIELD_NUMBER = 16;
        public static final int OPENGL_GPU_ENABLED_FIELD_NUMBER = 1;
        public static final int OPPORTUNITY_ID_PLACEMENT_VALIDATION_FIELD_NUMBER = 2;
        private static volatile Parser<FeatureFlags> PARSER = null;
        public static final int PRE_SHOW_WEBVIEW_STRATEGY_FIELD_NUMBER = 25;
        public static final int RECOVER_TERMINATED_WEBVIEWS_FIELD_NUMBER = 5;
        public static final int RETRY_SHOW_WITH_CURRENT_ACTIVITY_FIELD_NUMBER = 28;
        public static final int SHOULD_ALLOW_FETCH_TO_ACCESS_CACHE_FIELD_NUMBER = 23;
        public static final int SHOULD_HANDLE_WEBVIEW_CACHING_FIELD_NUMBER = 6;
        public static final int SHOULD_INIT_ADQ_WITH_GAME_ID_FIELD_NUMBER = 21;
        public static final int SHOULD_SEND_IAP_HISTORY_FIELD_NUMBER = 7;
        public static final int USE_CURRENT_ACTIVITY_FOR_SHOW_FIELD_NUMBER = 27;
        public static final int USE_FILES_DIR_FIELD_NUMBER = 11;
        public static final int USE_OPTIMISTIC_WEBVIEW_CACHE_FIELD_NUMBER = 17;
        public static final int USE_TRY_CATCH_IN_DOWNLOAD_QUEUE_FIELD_NUMBER = 12;
        public static final int WEBVIEW_LESS_LOAD_PARALLEL_ACTIVITY_LAUNCH_FIELD_NUMBER = 14;
        public static final int WEBVIEW_POOL_SIZE_FIELD_NUMBER = 26;
        private boolean appSheetBugCheckEnabled_;
        private boolean boldSdkNextSessionEnabled_;
        private boolean collectAccelerometer_;
        private boolean collectGoogleAppId_;
        private boolean collectIlrData_;
        private boolean collectLifecycleEvents_;
        private boolean disableCustomScheme_;
        private boolean disableGridCollection_;
        private boolean enableCoherenceLibrary_;
        private boolean ensureCacheFolderExistences_;
        private int fullscreenNavBarMode_;
        private boolean measureBridgePerformance_;
        private int nativeStartMode_;
        private boolean openglGpuEnabled_;
        private boolean opportunityIdPlacementValidation_;
        private int preShowWebviewStrategy_;
        private boolean recoverTerminatedWebviews_;
        private boolean retryShowWithCurrentActivity_;
        private boolean shouldAllowFetchToAccessCache_;
        private boolean shouldHandleWebviewCaching_;
        private boolean shouldInitAdqWithGameId_;
        private boolean shouldSendIapHistory_;
        private boolean useCurrentActivityForShow_;
        private boolean useFilesDir_;
        private boolean useOptimisticWebviewCache_;
        private boolean useTryCatchInDownloadQueue_;
        private boolean webviewLessLoadParallelActivityLaunch_;
        private int webviewPoolSize_;

        static {
            FeatureFlags featureFlags = new FeatureFlags();
            DEFAULT_INSTANCE = featureFlags;
            GeneratedMessageLite.registerDefaultInstance(FeatureFlags.class, featureFlags);
        }

        private FeatureFlags() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearAppSheetBugCheckEnabled() {
            this.appSheetBugCheckEnabled_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearBoldSdkNextSessionEnabled() {
            this.boldSdkNextSessionEnabled_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearCollectAccelerometer() {
            this.collectAccelerometer_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearCollectGoogleAppId() {
            this.collectGoogleAppId_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearCollectIlrData() {
            this.collectIlrData_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearCollectLifecycleEvents() {
            this.collectLifecycleEvents_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearDisableCustomScheme() {
            this.disableCustomScheme_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearDisableGridCollection() {
            this.disableGridCollection_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearEnableCoherenceLibrary() {
            this.enableCoherenceLibrary_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearEnsureCacheFolderExistences() {
            this.ensureCacheFolderExistences_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearFullscreenNavBarMode() {
            this.fullscreenNavBarMode_ = 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearMeasureBridgePerformance() {
            this.measureBridgePerformance_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearNativeStartMode() {
            this.nativeStartMode_ = 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearOpenglGpuEnabled() {
            this.openglGpuEnabled_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearOpportunityIdPlacementValidation() {
            this.opportunityIdPlacementValidation_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearPreShowWebviewStrategy() {
            this.preShowWebviewStrategy_ = 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearRecoverTerminatedWebviews() {
            this.recoverTerminatedWebviews_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearRetryShowWithCurrentActivity() {
            this.retryShowWithCurrentActivity_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearShouldAllowFetchToAccessCache() {
            this.shouldAllowFetchToAccessCache_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearShouldHandleWebviewCaching() {
            this.shouldHandleWebviewCaching_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearShouldInitAdqWithGameId() {
            this.shouldInitAdqWithGameId_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearShouldSendIapHistory() {
            this.shouldSendIapHistory_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearUseCurrentActivityForShow() {
            this.useCurrentActivityForShow_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearUseFilesDir() {
            this.useFilesDir_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearUseOptimisticWebviewCache() {
            this.useOptimisticWebviewCache_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearUseTryCatchInDownloadQueue() {
            this.useTryCatchInDownloadQueue_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearWebviewLessLoadParallelActivityLaunch() {
            this.webviewLessLoadParallelActivityLaunch_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearWebviewPoolSize() {
            this.webviewPoolSize_ = 0;
        }

        public static FeatureFlags getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return DEFAULT_INSTANCE.createBuilder();
        }

        public static FeatureFlags parseDelimitedFrom(InputStream inputStream) throws IOException {
            return (FeatureFlags) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static FeatureFlags parseFrom(ByteBuffer byteBuffer) throws InvalidProtocolBufferException {
            return (FeatureFlags) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<FeatureFlags> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setAppSheetBugCheckEnabled(boolean z) {
            this.appSheetBugCheckEnabled_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setBoldSdkNextSessionEnabled(boolean z) {
            this.boldSdkNextSessionEnabled_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setCollectAccelerometer(boolean z) {
            this.collectAccelerometer_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setCollectGoogleAppId(boolean z) {
            this.collectGoogleAppId_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setCollectIlrData(boolean z) {
            this.collectIlrData_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setCollectLifecycleEvents(boolean z) {
            this.collectLifecycleEvents_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setDisableCustomScheme(boolean z) {
            this.disableCustomScheme_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setDisableGridCollection(boolean z) {
            this.disableGridCollection_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setEnableCoherenceLibrary(boolean z) {
            this.enableCoherenceLibrary_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setEnsureCacheFolderExistences(boolean z) {
            this.ensureCacheFolderExistences_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setFullscreenNavBarMode(FullscreenNavBarMode fullscreenNavBarMode) {
            this.fullscreenNavBarMode_ = fullscreenNavBarMode.getNumber();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setFullscreenNavBarModeValue(int i) {
            this.fullscreenNavBarMode_ = i;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setMeasureBridgePerformance(boolean z) {
            this.measureBridgePerformance_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setNativeStartMode(NativeStartMode nativeStartMode) {
            this.nativeStartMode_ = nativeStartMode.getNumber();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setNativeStartModeValue(int i) {
            this.nativeStartMode_ = i;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setOpenglGpuEnabled(boolean z) {
            this.openglGpuEnabled_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setOpportunityIdPlacementValidation(boolean z) {
            this.opportunityIdPlacementValidation_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setPreShowWebviewStrategy(PreShowWebViewStrategy preShowWebViewStrategy) {
            this.preShowWebviewStrategy_ = preShowWebViewStrategy.getNumber();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setPreShowWebviewStrategyValue(int i) {
            this.preShowWebviewStrategy_ = i;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setRecoverTerminatedWebviews(boolean z) {
            this.recoverTerminatedWebviews_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setRetryShowWithCurrentActivity(boolean z) {
            this.retryShowWithCurrentActivity_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setShouldAllowFetchToAccessCache(boolean z) {
            this.shouldAllowFetchToAccessCache_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setShouldHandleWebviewCaching(boolean z) {
            this.shouldHandleWebviewCaching_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setShouldInitAdqWithGameId(boolean z) {
            this.shouldInitAdqWithGameId_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setShouldSendIapHistory(boolean z) {
            this.shouldSendIapHistory_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setUseCurrentActivityForShow(boolean z) {
            this.useCurrentActivityForShow_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setUseFilesDir(boolean z) {
            this.useFilesDir_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setUseOptimisticWebviewCache(boolean z) {
            this.useOptimisticWebviewCache_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setUseTryCatchInDownloadQueue(boolean z) {
            this.useTryCatchInDownloadQueue_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setWebviewLessLoadParallelActivityLaunch(boolean z) {
            this.webviewLessLoadParallelActivityLaunch_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setWebviewPoolSize(int i) {
            this.webviewPoolSize_ = i;
        }

        @Override // com.google.protobuf.GeneratedMessageLite
        public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            Parser parser;
            fg3 fg3Var = null;
            switch (fg3.f13801a[methodToInvoke.ordinal()]) {
                case 1:
                    return new FeatureFlags();
                case 2:
                    return new Builder(fg3Var);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u001c\u0000\u0000\u0001\u001c\u001c\u0000\u0000\u0000\u0001\u0007\u0002\u0007\u0003\u0007\u0004\u0007\u0005\u0007\u0006\u0007\u0007\u0007\b\u0007\t\u0007\n\u0007\u000b\u0007\f\u0007\r\u0007\u000e\u0007\u000f\u0007\u0010\f\u0011\u0007\u0012\u0007\u0013\u0007\u0014\f\u0015\u0007\u0016\u0007\u0017\u0007\u0018\u0007\u0019\f\u001a\u0004\u001b\u0007\u001c\u0007", new Object[]{"openglGpuEnabled_", "opportunityIdPlacementValidation_", "boldSdkNextSessionEnabled_", "appSheetBugCheckEnabled_", "recoverTerminatedWebviews_", "shouldHandleWebviewCaching_", "shouldSendIapHistory_", "collectIlrData_", "disableGridCollection_", "disableCustomScheme_", "useFilesDir_", "useTryCatchInDownloadQueue_", "ensureCacheFolderExistences_", "webviewLessLoadParallelActivityLaunch_", "collectLifecycleEvents_", "nativeStartMode_", "useOptimisticWebviewCache_", "collectGoogleAppId_", "enableCoherenceLibrary_", "fullscreenNavBarMode_", "shouldInitAdqWithGameId_", "collectAccelerometer_", "shouldAllowFetchToAccessCache_", "measureBridgePerformance_", "preShowWebviewStrategy_", "webviewPoolSize_", "useCurrentActivityForShow_", "retryShowWithCurrentActivity_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<FeatureFlags> parser2 = PARSER;
                    if (parser2 != null) {
                        return parser2;
                    }
                    synchronized (FeatureFlags.class) {
                        parser = PARSER;
                        if (parser == null) {
                            parser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                            PARSER = parser;
                        }
                    }
                    return parser;
                case 6:
                    return (byte) 1;
                default:
                    C0950f.m10573c();
                case 7:
                    return null;
            }
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getAppSheetBugCheckEnabled() {
            return this.appSheetBugCheckEnabled_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getBoldSdkNextSessionEnabled() {
            return this.boldSdkNextSessionEnabled_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getCollectAccelerometer() {
            return this.collectAccelerometer_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getCollectGoogleAppId() {
            return this.collectGoogleAppId_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getCollectIlrData() {
            return this.collectIlrData_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getCollectLifecycleEvents() {
            return this.collectLifecycleEvents_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getDisableCustomScheme() {
            return this.disableCustomScheme_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getDisableGridCollection() {
            return this.disableGridCollection_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getEnableCoherenceLibrary() {
            return this.enableCoherenceLibrary_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getEnsureCacheFolderExistences() {
            return this.ensureCacheFolderExistences_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public FullscreenNavBarMode getFullscreenNavBarMode() {
            FullscreenNavBarMode forNumber = FullscreenNavBarMode.forNumber(this.fullscreenNavBarMode_);
            return forNumber == null ? FullscreenNavBarMode.UNRECOGNIZED : forNumber;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public int getFullscreenNavBarModeValue() {
            return this.fullscreenNavBarMode_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getMeasureBridgePerformance() {
            return this.measureBridgePerformance_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public NativeStartMode getNativeStartMode() {
            NativeStartMode forNumber = NativeStartMode.forNumber(this.nativeStartMode_);
            return forNumber == null ? NativeStartMode.UNRECOGNIZED : forNumber;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public int getNativeStartModeValue() {
            return this.nativeStartMode_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getOpenglGpuEnabled() {
            return this.openglGpuEnabled_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getOpportunityIdPlacementValidation() {
            return this.opportunityIdPlacementValidation_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public PreShowWebViewStrategy getPreShowWebviewStrategy() {
            PreShowWebViewStrategy forNumber = PreShowWebViewStrategy.forNumber(this.preShowWebviewStrategy_);
            return forNumber == null ? PreShowWebViewStrategy.UNRECOGNIZED : forNumber;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public int getPreShowWebviewStrategyValue() {
            return this.preShowWebviewStrategy_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getRecoverTerminatedWebviews() {
            return this.recoverTerminatedWebviews_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getRetryShowWithCurrentActivity() {
            return this.retryShowWithCurrentActivity_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getShouldAllowFetchToAccessCache() {
            return this.shouldAllowFetchToAccessCache_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getShouldHandleWebviewCaching() {
            return this.shouldHandleWebviewCaching_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getShouldInitAdqWithGameId() {
            return this.shouldInitAdqWithGameId_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getShouldSendIapHistory() {
            return this.shouldSendIapHistory_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getUseCurrentActivityForShow() {
            return this.useCurrentActivityForShow_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getUseFilesDir() {
            return this.useFilesDir_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getUseOptimisticWebviewCache() {
            return this.useOptimisticWebviewCache_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getUseTryCatchInDownloadQueue() {
            return this.useTryCatchInDownloadQueue_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public boolean getWebviewLessLoadParallelActivityLaunch() {
            return this.webviewLessLoadParallelActivityLaunch_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
        public int getWebviewPoolSize() {
            return this.webviewPoolSize_;
        }

        /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
        public static final class Builder extends GeneratedMessageLite.Builder<FeatureFlags, Builder> implements FeatureFlagsOrBuilder {
            private Builder() {
                super(FeatureFlags.DEFAULT_INSTANCE);
            }

            public Builder clearAppSheetBugCheckEnabled() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearAppSheetBugCheckEnabled();
                return this;
            }

            public Builder clearBoldSdkNextSessionEnabled() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearBoldSdkNextSessionEnabled();
                return this;
            }

            public Builder clearCollectAccelerometer() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearCollectAccelerometer();
                return this;
            }

            public Builder clearCollectGoogleAppId() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearCollectGoogleAppId();
                return this;
            }

            public Builder clearCollectIlrData() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearCollectIlrData();
                return this;
            }

            public Builder clearCollectLifecycleEvents() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearCollectLifecycleEvents();
                return this;
            }

            public Builder clearDisableCustomScheme() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearDisableCustomScheme();
                return this;
            }

            public Builder clearDisableGridCollection() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearDisableGridCollection();
                return this;
            }

            public Builder clearEnableCoherenceLibrary() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearEnableCoherenceLibrary();
                return this;
            }

            public Builder clearEnsureCacheFolderExistences() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearEnsureCacheFolderExistences();
                return this;
            }

            public Builder clearFullscreenNavBarMode() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearFullscreenNavBarMode();
                return this;
            }

            public Builder clearMeasureBridgePerformance() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearMeasureBridgePerformance();
                return this;
            }

            public Builder clearNativeStartMode() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearNativeStartMode();
                return this;
            }

            public Builder clearOpenglGpuEnabled() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearOpenglGpuEnabled();
                return this;
            }

            public Builder clearOpportunityIdPlacementValidation() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearOpportunityIdPlacementValidation();
                return this;
            }

            public Builder clearPreShowWebviewStrategy() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearPreShowWebviewStrategy();
                return this;
            }

            public Builder clearRecoverTerminatedWebviews() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearRecoverTerminatedWebviews();
                return this;
            }

            public Builder clearRetryShowWithCurrentActivity() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearRetryShowWithCurrentActivity();
                return this;
            }

            public Builder clearShouldAllowFetchToAccessCache() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearShouldAllowFetchToAccessCache();
                return this;
            }

            public Builder clearShouldHandleWebviewCaching() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearShouldHandleWebviewCaching();
                return this;
            }

            public Builder clearShouldInitAdqWithGameId() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearShouldInitAdqWithGameId();
                return this;
            }

            public Builder clearShouldSendIapHistory() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearShouldSendIapHistory();
                return this;
            }

            public Builder clearUseCurrentActivityForShow() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearUseCurrentActivityForShow();
                return this;
            }

            public Builder clearUseFilesDir() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearUseFilesDir();
                return this;
            }

            public Builder clearUseOptimisticWebviewCache() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearUseOptimisticWebviewCache();
                return this;
            }

            public Builder clearUseTryCatchInDownloadQueue() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearUseTryCatchInDownloadQueue();
                return this;
            }

            public Builder clearWebviewLessLoadParallelActivityLaunch() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearWebviewLessLoadParallelActivityLaunch();
                return this;
            }

            public Builder clearWebviewPoolSize() {
                copyOnWrite();
                ((FeatureFlags) this.instance).clearWebviewPoolSize();
                return this;
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getAppSheetBugCheckEnabled() {
                return ((FeatureFlags) this.instance).getAppSheetBugCheckEnabled();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getBoldSdkNextSessionEnabled() {
                return ((FeatureFlags) this.instance).getBoldSdkNextSessionEnabled();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getCollectAccelerometer() {
                return ((FeatureFlags) this.instance).getCollectAccelerometer();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getCollectGoogleAppId() {
                return ((FeatureFlags) this.instance).getCollectGoogleAppId();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getCollectIlrData() {
                return ((FeatureFlags) this.instance).getCollectIlrData();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getCollectLifecycleEvents() {
                return ((FeatureFlags) this.instance).getCollectLifecycleEvents();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getDisableCustomScheme() {
                return ((FeatureFlags) this.instance).getDisableCustomScheme();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getDisableGridCollection() {
                return ((FeatureFlags) this.instance).getDisableGridCollection();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getEnableCoherenceLibrary() {
                return ((FeatureFlags) this.instance).getEnableCoherenceLibrary();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getEnsureCacheFolderExistences() {
                return ((FeatureFlags) this.instance).getEnsureCacheFolderExistences();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public FullscreenNavBarMode getFullscreenNavBarMode() {
                return ((FeatureFlags) this.instance).getFullscreenNavBarMode();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public int getFullscreenNavBarModeValue() {
                return ((FeatureFlags) this.instance).getFullscreenNavBarModeValue();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getMeasureBridgePerformance() {
                return ((FeatureFlags) this.instance).getMeasureBridgePerformance();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public NativeStartMode getNativeStartMode() {
                return ((FeatureFlags) this.instance).getNativeStartMode();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public int getNativeStartModeValue() {
                return ((FeatureFlags) this.instance).getNativeStartModeValue();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getOpenglGpuEnabled() {
                return ((FeatureFlags) this.instance).getOpenglGpuEnabled();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getOpportunityIdPlacementValidation() {
                return ((FeatureFlags) this.instance).getOpportunityIdPlacementValidation();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public PreShowWebViewStrategy getPreShowWebviewStrategy() {
                return ((FeatureFlags) this.instance).getPreShowWebviewStrategy();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public int getPreShowWebviewStrategyValue() {
                return ((FeatureFlags) this.instance).getPreShowWebviewStrategyValue();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getRecoverTerminatedWebviews() {
                return ((FeatureFlags) this.instance).getRecoverTerminatedWebviews();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getRetryShowWithCurrentActivity() {
                return ((FeatureFlags) this.instance).getRetryShowWithCurrentActivity();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getShouldAllowFetchToAccessCache() {
                return ((FeatureFlags) this.instance).getShouldAllowFetchToAccessCache();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getShouldHandleWebviewCaching() {
                return ((FeatureFlags) this.instance).getShouldHandleWebviewCaching();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getShouldInitAdqWithGameId() {
                return ((FeatureFlags) this.instance).getShouldInitAdqWithGameId();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getShouldSendIapHistory() {
                return ((FeatureFlags) this.instance).getShouldSendIapHistory();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getUseCurrentActivityForShow() {
                return ((FeatureFlags) this.instance).getUseCurrentActivityForShow();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getUseFilesDir() {
                return ((FeatureFlags) this.instance).getUseFilesDir();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getUseOptimisticWebviewCache() {
                return ((FeatureFlags) this.instance).getUseOptimisticWebviewCache();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getUseTryCatchInDownloadQueue() {
                return ((FeatureFlags) this.instance).getUseTryCatchInDownloadQueue();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public boolean getWebviewLessLoadParallelActivityLaunch() {
                return ((FeatureFlags) this.instance).getWebviewLessLoadParallelActivityLaunch();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlagsOrBuilder
            public int getWebviewPoolSize() {
                return ((FeatureFlags) this.instance).getWebviewPoolSize();
            }

            public Builder setAppSheetBugCheckEnabled(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setAppSheetBugCheckEnabled(z);
                return this;
            }

            public Builder setBoldSdkNextSessionEnabled(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setBoldSdkNextSessionEnabled(z);
                return this;
            }

            public Builder setCollectAccelerometer(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setCollectAccelerometer(z);
                return this;
            }

            public Builder setCollectGoogleAppId(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setCollectGoogleAppId(z);
                return this;
            }

            public Builder setCollectIlrData(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setCollectIlrData(z);
                return this;
            }

            public Builder setCollectLifecycleEvents(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setCollectLifecycleEvents(z);
                return this;
            }

            public Builder setDisableCustomScheme(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setDisableCustomScheme(z);
                return this;
            }

            public Builder setDisableGridCollection(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setDisableGridCollection(z);
                return this;
            }

            public Builder setEnableCoherenceLibrary(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setEnableCoherenceLibrary(z);
                return this;
            }

            public Builder setEnsureCacheFolderExistences(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setEnsureCacheFolderExistences(z);
                return this;
            }

            public Builder setFullscreenNavBarMode(FullscreenNavBarMode fullscreenNavBarMode) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setFullscreenNavBarMode(fullscreenNavBarMode);
                return this;
            }

            public Builder setFullscreenNavBarModeValue(int i) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setFullscreenNavBarModeValue(i);
                return this;
            }

            public Builder setMeasureBridgePerformance(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setMeasureBridgePerformance(z);
                return this;
            }

            public Builder setNativeStartMode(NativeStartMode nativeStartMode) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setNativeStartMode(nativeStartMode);
                return this;
            }

            public Builder setNativeStartModeValue(int i) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setNativeStartModeValue(i);
                return this;
            }

            public Builder setOpenglGpuEnabled(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setOpenglGpuEnabled(z);
                return this;
            }

            public Builder setOpportunityIdPlacementValidation(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setOpportunityIdPlacementValidation(z);
                return this;
            }

            public Builder setPreShowWebviewStrategy(PreShowWebViewStrategy preShowWebViewStrategy) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setPreShowWebviewStrategy(preShowWebViewStrategy);
                return this;
            }

            public Builder setPreShowWebviewStrategyValue(int i) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setPreShowWebviewStrategyValue(i);
                return this;
            }

            public Builder setRecoverTerminatedWebviews(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setRecoverTerminatedWebviews(z);
                return this;
            }

            public Builder setRetryShowWithCurrentActivity(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setRetryShowWithCurrentActivity(z);
                return this;
            }

            public Builder setShouldAllowFetchToAccessCache(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setShouldAllowFetchToAccessCache(z);
                return this;
            }

            public Builder setShouldHandleWebviewCaching(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setShouldHandleWebviewCaching(z);
                return this;
            }

            public Builder setShouldInitAdqWithGameId(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setShouldInitAdqWithGameId(z);
                return this;
            }

            public Builder setShouldSendIapHistory(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setShouldSendIapHistory(z);
                return this;
            }

            public Builder setUseCurrentActivityForShow(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setUseCurrentActivityForShow(z);
                return this;
            }

            public Builder setUseFilesDir(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setUseFilesDir(z);
                return this;
            }

            public Builder setUseOptimisticWebviewCache(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setUseOptimisticWebviewCache(z);
                return this;
            }

            public Builder setUseTryCatchInDownloadQueue(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setUseTryCatchInDownloadQueue(z);
                return this;
            }

            public Builder setWebviewLessLoadParallelActivityLaunch(boolean z) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setWebviewLessLoadParallelActivityLaunch(z);
                return this;
            }

            public Builder setWebviewPoolSize(int i) {
                copyOnWrite();
                ((FeatureFlags) this.instance).setWebviewPoolSize(i);
                return this;
            }

            public /* synthetic */ Builder(fg3 fg3Var) {
                this();
            }
        }

        public static Builder newBuilder(FeatureFlags featureFlags) {
            return DEFAULT_INSTANCE.createBuilder(featureFlags);
        }

        public static FeatureFlags parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (FeatureFlags) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static FeatureFlags parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (FeatureFlags) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static FeatureFlags parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return (FeatureFlags) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static FeatureFlags parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (FeatureFlags) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static FeatureFlags parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return (FeatureFlags) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static FeatureFlags parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (FeatureFlags) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static FeatureFlags parseFrom(InputStream inputStream) throws IOException {
            return (FeatureFlags) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static FeatureFlags parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (FeatureFlags) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static FeatureFlags parseFrom(CodedInputStream codedInputStream) throws IOException {
            return (FeatureFlags) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static FeatureFlags parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (FeatureFlags) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public static final class NativeConfiguration extends GeneratedMessageLite<NativeConfiguration, Builder> implements NativeConfigurationOrBuilder {
        public static final int ACCELEROMETER_COLLECTION_FIELD_NUMBER = 23;
        public static final int ADDITIONAL_STORE_PACKAGES_FIELD_NUMBER = 10;
        public static final int AD_OPERATIONS_FIELD_NUMBER = 6;
        public static final int AD_POLICY_FIELD_NUMBER = 3;
        public static final int CACHED_ASSETS_CONFIGURATION_FIELD_NUMBER = 11;
        public static final int CACHED_WEBVIEW_FILES_CONFIGURATION_FIELD_NUMBER = 13;
        public static final int DEBUG_SETTINGS_FIELD_NUMBER = 16;
        private static final NativeConfiguration DEFAULT_INSTANCE;
        public static final int DEFAULT_SHOW_COMPLETION_STATE_FIELD_NUMBER = 14;
        public static final int DIAGNOSTIC_EVENTS_FIELD_NUMBER = 1;
        public static final int DOWNLOAD_POLICY_FIELD_NUMBER = 15;
        public static final int ENABLE_IAP_EVENT_FIELD_NUMBER = 8;
        public static final int ENABLE_OM_FIELD_NUMBER = 9;
        public static final int FEATURE_FLAGS_FIELD_NUMBER = 7;
        public static final int INIT_POLICY_FIELD_NUMBER = 2;
        public static final int LEVEL_PLAY_APP_KEY_FIELD_NUMBER = 22;
        public static final int MAX_EXTRAS_SIZE_KB_FIELD_NUMBER = 17;
        public static final int MAX_RECEIPT_SIZE_MB_FIELD_NUMBER = 18;
        public static final int MONITORING_IDS_FIELD_NUMBER = 21;
        public static final int OBSERVABLE_ANDROID_ACTIVITIES_FIELD_NUMBER = 12;
        public static final int OBSERVABLE_VIEW_CONTROLLERS_FIELD_NUMBER = 20;
        public static final int OPERATIVE_EVENT_POLICY_FIELD_NUMBER = 4;
        public static final int OPTIMISTIC_INIT_DELAY_MS_FIELD_NUMBER = 24;
        public static final int OTHER_POLICY_FIELD_NUMBER = 5;
        public static final int OVERWRITE_INTENT_FLAG_ACTIVITY_FIELD_NUMBER = 19;
        private static volatile Parser<NativeConfiguration> PARSER;
        private AccelerometerCollectionConfiguration accelerometerCollection_;
        private AdOperationsConfiguration adOperations_;
        private RequestPolicy adPolicy_;
        private int bitField0_;
        private CachedAssetsConfiguration cachedAssetsConfiguration_;
        private CachedAssetsConfiguration cachedWebviewFilesConfiguration_;
        private DebugSettings debugSettings_;
        private int defaultShowCompletionState_;
        private DiagnosticEventsConfiguration diagnosticEvents_;
        private RequestPolicy downloadPolicy_;
        private boolean enableIapEvent_;
        private boolean enableOm_;
        private FeatureFlags featureFlags_;
        private RequestPolicy initPolicy_;
        private int maxExtrasSizeKb_;
        private int maxReceiptSizeMb_;
        private RequestPolicy operativeEventPolicy_;
        private int optimisticInitDelayMs_;
        private RequestPolicy otherPolicy_;
        private int overwriteIntentFlagActivity_;
        private int monitoringIdsMemoizedSerializedSize = -1;
        private Internal.ProtobufList<String> additionalStorePackages_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<ByteString> observableAndroidActivities_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<ByteString> observableViewControllers_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.IntList monitoringIds_ = GeneratedMessageLite.emptyIntList();
        private String levelPlayAppKey_ = "";

        static {
            NativeConfiguration nativeConfiguration = new NativeConfiguration();
            DEFAULT_INSTANCE = nativeConfiguration;
            GeneratedMessageLite.registerDefaultInstance(NativeConfiguration.class, nativeConfiguration);
        }

        private NativeConfiguration() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void addAdditionalStorePackages(String str) {
            str.getClass();
            ensureAdditionalStorePackagesIsMutable();
            this.additionalStorePackages_.add(str);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void addAdditionalStorePackagesBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureAdditionalStorePackagesIsMutable();
            this.additionalStorePackages_.add(byteString.toStringUtf8());
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void addAllAdditionalStorePackages(Iterable<String> iterable) {
            ensureAdditionalStorePackagesIsMutable();
            AbstractMessageLite.addAll((Iterable) iterable, (List) this.additionalStorePackages_);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void addAllMonitoringIds(Iterable<? extends Integer> iterable) {
            ensureMonitoringIdsIsMutable();
            AbstractMessageLite.addAll((Iterable) iterable, (List) this.monitoringIds_);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void addAllObservableAndroidActivities(Iterable<? extends ByteString> iterable) {
            ensureObservableAndroidActivitiesIsMutable();
            AbstractMessageLite.addAll((Iterable) iterable, (List) this.observableAndroidActivities_);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void addAllObservableViewControllers(Iterable<? extends ByteString> iterable) {
            ensureObservableViewControllersIsMutable();
            AbstractMessageLite.addAll((Iterable) iterable, (List) this.observableViewControllers_);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void addMonitoringIds(int i) {
            ensureMonitoringIdsIsMutable();
            this.monitoringIds_.addInt(i);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void addObservableAndroidActivities(ByteString byteString) {
            byteString.getClass();
            ensureObservableAndroidActivitiesIsMutable();
            this.observableAndroidActivities_.add(byteString);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void addObservableViewControllers(ByteString byteString) {
            byteString.getClass();
            ensureObservableViewControllersIsMutable();
            this.observableViewControllers_.add(byteString);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearAccelerometerCollection() {
            this.accelerometerCollection_ = null;
            this.bitField0_ &= -4097;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearAdOperations() {
            this.adOperations_ = null;
            this.bitField0_ &= -33;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearAdPolicy() {
            this.adPolicy_ = null;
            this.bitField0_ &= -5;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearAdditionalStorePackages() {
            this.additionalStorePackages_ = GeneratedMessageLite.emptyProtobufList();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearCachedAssetsConfiguration() {
            this.cachedAssetsConfiguration_ = null;
            this.bitField0_ &= -129;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearCachedWebviewFilesConfiguration() {
            this.cachedWebviewFilesConfiguration_ = null;
            this.bitField0_ &= -257;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearDebugSettings() {
            this.debugSettings_ = null;
            this.bitField0_ &= -1025;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearDefaultShowCompletionState() {
            this.defaultShowCompletionState_ = 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearDiagnosticEvents() {
            this.diagnosticEvents_ = null;
            this.bitField0_ &= -2;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearDownloadPolicy() {
            this.downloadPolicy_ = null;
            this.bitField0_ &= -513;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearEnableIapEvent() {
            this.enableIapEvent_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearEnableOm() {
            this.enableOm_ = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearFeatureFlags() {
            this.featureFlags_ = null;
            this.bitField0_ &= -65;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearInitPolicy() {
            this.initPolicy_ = null;
            this.bitField0_ &= -3;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearLevelPlayAppKey() {
            this.bitField0_ &= -2049;
            this.levelPlayAppKey_ = getDefaultInstance().getLevelPlayAppKey();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearMaxExtrasSizeKb() {
            this.maxExtrasSizeKb_ = 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearMaxReceiptSizeMb() {
            this.maxReceiptSizeMb_ = 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearMonitoringIds() {
            this.monitoringIds_ = GeneratedMessageLite.emptyIntList();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearObservableAndroidActivities() {
            this.observableAndroidActivities_ = GeneratedMessageLite.emptyProtobufList();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearObservableViewControllers() {
            this.observableViewControllers_ = GeneratedMessageLite.emptyProtobufList();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearOperativeEventPolicy() {
            this.operativeEventPolicy_ = null;
            this.bitField0_ &= -9;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearOptimisticInitDelayMs() {
            this.bitField0_ &= -8193;
            this.optimisticInitDelayMs_ = 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearOtherPolicy() {
            this.otherPolicy_ = null;
            this.bitField0_ &= -17;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearOverwriteIntentFlagActivity() {
            this.overwriteIntentFlagActivity_ = 0;
        }

        private void ensureAdditionalStorePackagesIsMutable() {
            Internal.ProtobufList<String> protobufList = this.additionalStorePackages_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.additionalStorePackages_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureMonitoringIdsIsMutable() {
            Internal.IntList intList = this.monitoringIds_;
            if (intList.isModifiable()) {
                return;
            }
            this.monitoringIds_ = GeneratedMessageLite.mutableCopy(intList);
        }

        private void ensureObservableAndroidActivitiesIsMutable() {
            Internal.ProtobufList<ByteString> protobufList = this.observableAndroidActivities_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.observableAndroidActivities_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureObservableViewControllersIsMutable() {
            Internal.ProtobufList<ByteString> protobufList = this.observableViewControllers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.observableViewControllers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static NativeConfiguration getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void mergeAccelerometerCollection(AccelerometerCollectionConfiguration accelerometerCollectionConfiguration) {
            accelerometerCollectionConfiguration.getClass();
            AccelerometerCollectionConfiguration accelerometerCollectionConfiguration2 = this.accelerometerCollection_;
            if (accelerometerCollectionConfiguration2 == null || accelerometerCollectionConfiguration2 == AccelerometerCollectionConfiguration.getDefaultInstance()) {
                this.accelerometerCollection_ = accelerometerCollectionConfiguration;
            } else {
                this.accelerometerCollection_ = AccelerometerCollectionConfiguration.newBuilder(this.accelerometerCollection_).mergeFrom((AccelerometerCollectionConfiguration.Builder) accelerometerCollectionConfiguration).buildPartial();
            }
            this.bitField0_ |= 4096;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void mergeAdOperations(AdOperationsConfiguration adOperationsConfiguration) {
            adOperationsConfiguration.getClass();
            AdOperationsConfiguration adOperationsConfiguration2 = this.adOperations_;
            if (adOperationsConfiguration2 == null || adOperationsConfiguration2 == AdOperationsConfiguration.getDefaultInstance()) {
                this.adOperations_ = adOperationsConfiguration;
            } else {
                this.adOperations_ = AdOperationsConfiguration.newBuilder(this.adOperations_).mergeFrom((AdOperationsConfiguration.Builder) adOperationsConfiguration).buildPartial();
            }
            this.bitField0_ |= 32;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void mergeAdPolicy(RequestPolicy requestPolicy) {
            requestPolicy.getClass();
            RequestPolicy requestPolicy2 = this.adPolicy_;
            if (requestPolicy2 == null || requestPolicy2 == RequestPolicy.getDefaultInstance()) {
                this.adPolicy_ = requestPolicy;
            } else {
                this.adPolicy_ = RequestPolicy.newBuilder(this.adPolicy_).mergeFrom((RequestPolicy.Builder) requestPolicy).buildPartial();
            }
            this.bitField0_ |= 4;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void mergeCachedAssetsConfiguration(CachedAssetsConfiguration cachedAssetsConfiguration) {
            cachedAssetsConfiguration.getClass();
            CachedAssetsConfiguration cachedAssetsConfiguration2 = this.cachedAssetsConfiguration_;
            if (cachedAssetsConfiguration2 == null || cachedAssetsConfiguration2 == CachedAssetsConfiguration.getDefaultInstance()) {
                this.cachedAssetsConfiguration_ = cachedAssetsConfiguration;
            } else {
                this.cachedAssetsConfiguration_ = CachedAssetsConfiguration.newBuilder(this.cachedAssetsConfiguration_).mergeFrom((CachedAssetsConfiguration.Builder) cachedAssetsConfiguration).buildPartial();
            }
            this.bitField0_ |= 128;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void mergeCachedWebviewFilesConfiguration(CachedAssetsConfiguration cachedAssetsConfiguration) {
            cachedAssetsConfiguration.getClass();
            CachedAssetsConfiguration cachedAssetsConfiguration2 = this.cachedWebviewFilesConfiguration_;
            if (cachedAssetsConfiguration2 == null || cachedAssetsConfiguration2 == CachedAssetsConfiguration.getDefaultInstance()) {
                this.cachedWebviewFilesConfiguration_ = cachedAssetsConfiguration;
            } else {
                this.cachedWebviewFilesConfiguration_ = CachedAssetsConfiguration.newBuilder(this.cachedWebviewFilesConfiguration_).mergeFrom((CachedAssetsConfiguration.Builder) cachedAssetsConfiguration).buildPartial();
            }
            this.bitField0_ |= 256;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void mergeDebugSettings(DebugSettings debugSettings) {
            debugSettings.getClass();
            DebugSettings debugSettings2 = this.debugSettings_;
            if (debugSettings2 == null || debugSettings2 == DebugSettings.getDefaultInstance()) {
                this.debugSettings_ = debugSettings;
            } else {
                this.debugSettings_ = DebugSettings.newBuilder(this.debugSettings_).mergeFrom((DebugSettings.Builder) debugSettings).buildPartial();
            }
            this.bitField0_ |= 1024;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void mergeDiagnosticEvents(DiagnosticEventsConfiguration diagnosticEventsConfiguration) {
            diagnosticEventsConfiguration.getClass();
            DiagnosticEventsConfiguration diagnosticEventsConfiguration2 = this.diagnosticEvents_;
            if (diagnosticEventsConfiguration2 == null || diagnosticEventsConfiguration2 == DiagnosticEventsConfiguration.getDefaultInstance()) {
                this.diagnosticEvents_ = diagnosticEventsConfiguration;
            } else {
                this.diagnosticEvents_ = DiagnosticEventsConfiguration.newBuilder(this.diagnosticEvents_).mergeFrom((DiagnosticEventsConfiguration.Builder) diagnosticEventsConfiguration).buildPartial();
            }
            this.bitField0_ |= 1;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void mergeDownloadPolicy(RequestPolicy requestPolicy) {
            requestPolicy.getClass();
            RequestPolicy requestPolicy2 = this.downloadPolicy_;
            if (requestPolicy2 == null || requestPolicy2 == RequestPolicy.getDefaultInstance()) {
                this.downloadPolicy_ = requestPolicy;
            } else {
                this.downloadPolicy_ = RequestPolicy.newBuilder(this.downloadPolicy_).mergeFrom((RequestPolicy.Builder) requestPolicy).buildPartial();
            }
            this.bitField0_ |= 512;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void mergeFeatureFlags(FeatureFlags featureFlags) {
            featureFlags.getClass();
            FeatureFlags featureFlags2 = this.featureFlags_;
            if (featureFlags2 == null || featureFlags2 == FeatureFlags.getDefaultInstance()) {
                this.featureFlags_ = featureFlags;
            } else {
                this.featureFlags_ = FeatureFlags.newBuilder(this.featureFlags_).mergeFrom((FeatureFlags.Builder) featureFlags).buildPartial();
            }
            this.bitField0_ |= 64;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void mergeInitPolicy(RequestPolicy requestPolicy) {
            requestPolicy.getClass();
            RequestPolicy requestPolicy2 = this.initPolicy_;
            if (requestPolicy2 == null || requestPolicy2 == RequestPolicy.getDefaultInstance()) {
                this.initPolicy_ = requestPolicy;
            } else {
                this.initPolicy_ = RequestPolicy.newBuilder(this.initPolicy_).mergeFrom((RequestPolicy.Builder) requestPolicy).buildPartial();
            }
            this.bitField0_ |= 2;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void mergeOperativeEventPolicy(RequestPolicy requestPolicy) {
            requestPolicy.getClass();
            RequestPolicy requestPolicy2 = this.operativeEventPolicy_;
            if (requestPolicy2 == null || requestPolicy2 == RequestPolicy.getDefaultInstance()) {
                this.operativeEventPolicy_ = requestPolicy;
            } else {
                this.operativeEventPolicy_ = RequestPolicy.newBuilder(this.operativeEventPolicy_).mergeFrom((RequestPolicy.Builder) requestPolicy).buildPartial();
            }
            this.bitField0_ |= 8;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void mergeOtherPolicy(RequestPolicy requestPolicy) {
            requestPolicy.getClass();
            RequestPolicy requestPolicy2 = this.otherPolicy_;
            if (requestPolicy2 == null || requestPolicy2 == RequestPolicy.getDefaultInstance()) {
                this.otherPolicy_ = requestPolicy;
            } else {
                this.otherPolicy_ = RequestPolicy.newBuilder(this.otherPolicy_).mergeFrom((RequestPolicy.Builder) requestPolicy).buildPartial();
            }
            this.bitField0_ |= 16;
        }

        public static Builder newBuilder() {
            return DEFAULT_INSTANCE.createBuilder();
        }

        public static NativeConfiguration parseDelimitedFrom(InputStream inputStream) throws IOException {
            return (NativeConfiguration) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static NativeConfiguration parseFrom(ByteBuffer byteBuffer) throws InvalidProtocolBufferException {
            return (NativeConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<NativeConfiguration> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setAccelerometerCollection(AccelerometerCollectionConfiguration accelerometerCollectionConfiguration) {
            accelerometerCollectionConfiguration.getClass();
            this.accelerometerCollection_ = accelerometerCollectionConfiguration;
            this.bitField0_ |= 4096;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setAdOperations(AdOperationsConfiguration adOperationsConfiguration) {
            adOperationsConfiguration.getClass();
            this.adOperations_ = adOperationsConfiguration;
            this.bitField0_ |= 32;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setAdPolicy(RequestPolicy requestPolicy) {
            requestPolicy.getClass();
            this.adPolicy_ = requestPolicy;
            this.bitField0_ |= 4;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setAdditionalStorePackages(int i, String str) {
            str.getClass();
            ensureAdditionalStorePackagesIsMutable();
            this.additionalStorePackages_.set(i, str);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setCachedAssetsConfiguration(CachedAssetsConfiguration cachedAssetsConfiguration) {
            cachedAssetsConfiguration.getClass();
            this.cachedAssetsConfiguration_ = cachedAssetsConfiguration;
            this.bitField0_ |= 128;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setCachedWebviewFilesConfiguration(CachedAssetsConfiguration cachedAssetsConfiguration) {
            cachedAssetsConfiguration.getClass();
            this.cachedWebviewFilesConfiguration_ = cachedAssetsConfiguration;
            this.bitField0_ |= 256;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setDebugSettings(DebugSettings debugSettings) {
            debugSettings.getClass();
            this.debugSettings_ = debugSettings;
            this.bitField0_ |= 1024;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setDefaultShowCompletionState(ShowCompletionState showCompletionState) {
            this.defaultShowCompletionState_ = showCompletionState.getNumber();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setDefaultShowCompletionStateValue(int i) {
            this.defaultShowCompletionState_ = i;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setDiagnosticEvents(DiagnosticEventsConfiguration diagnosticEventsConfiguration) {
            diagnosticEventsConfiguration.getClass();
            this.diagnosticEvents_ = diagnosticEventsConfiguration;
            this.bitField0_ |= 1;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setDownloadPolicy(RequestPolicy requestPolicy) {
            requestPolicy.getClass();
            this.downloadPolicy_ = requestPolicy;
            this.bitField0_ |= 512;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setEnableIapEvent(boolean z) {
            this.enableIapEvent_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setEnableOm(boolean z) {
            this.enableOm_ = z;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setFeatureFlags(FeatureFlags featureFlags) {
            featureFlags.getClass();
            this.featureFlags_ = featureFlags;
            this.bitField0_ |= 64;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setInitPolicy(RequestPolicy requestPolicy) {
            requestPolicy.getClass();
            this.initPolicy_ = requestPolicy;
            this.bitField0_ |= 2;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setLevelPlayAppKey(String str) {
            str.getClass();
            this.bitField0_ |= 2048;
            this.levelPlayAppKey_ = str;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setLevelPlayAppKeyBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.levelPlayAppKey_ = byteString.toStringUtf8();
            this.bitField0_ |= 2048;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setMaxExtrasSizeKb(int i) {
            this.maxExtrasSizeKb_ = i;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setMaxReceiptSizeMb(int i) {
            this.maxReceiptSizeMb_ = i;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setMonitoringIds(int i, int i2) {
            ensureMonitoringIdsIsMutable();
            this.monitoringIds_.setInt(i, i2);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setObservableAndroidActivities(int i, ByteString byteString) {
            byteString.getClass();
            ensureObservableAndroidActivitiesIsMutable();
            this.observableAndroidActivities_.set(i, byteString);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setObservableViewControllers(int i, ByteString byteString) {
            byteString.getClass();
            ensureObservableViewControllersIsMutable();
            this.observableViewControllers_.set(i, byteString);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setOperativeEventPolicy(RequestPolicy requestPolicy) {
            requestPolicy.getClass();
            this.operativeEventPolicy_ = requestPolicy;
            this.bitField0_ |= 8;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setOptimisticInitDelayMs(int i) {
            this.bitField0_ |= Segment.SIZE;
            this.optimisticInitDelayMs_ = i;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setOtherPolicy(RequestPolicy requestPolicy) {
            requestPolicy.getClass();
            this.otherPolicy_ = requestPolicy;
            this.bitField0_ |= 16;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setOverwriteIntentFlagActivity(int i) {
            this.overwriteIntentFlagActivity_ = i;
        }

        @Override // com.google.protobuf.GeneratedMessageLite
        public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            Parser parser;
            fg3 fg3Var = null;
            switch (fg3.f13801a[methodToInvoke.ordinal()]) {
                case 1:
                    return new NativeConfiguration();
                case 2:
                    return new Builder(fg3Var);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0018\u0000\u0001\u0001\u0018\u0018\u0000\u0004\u0000\u0001ဉ\u0000\u0002ဉ\u0001\u0003ဉ\u0002\u0004ဉ\u0003\u0005ဉ\u0004\u0006ဉ\u0005\u0007ဉ\u0006\b\u0007\t\u0007\nȚ\u000bဉ\u0007\f\u001c\rဉ\b\u000e\f\u000fဉ\t\u0010ဉ\n\u0011\u0004\u0012\u0004\u0013\u0004\u0014\u001c\u0015'\u0016ለ\u000b\u0017ဉ\f\u0018င\r", new Object[]{"bitField0_", "diagnosticEvents_", "initPolicy_", "adPolicy_", "operativeEventPolicy_", "otherPolicy_", "adOperations_", "featureFlags_", "enableIapEvent_", "enableOm_", "additionalStorePackages_", "cachedAssetsConfiguration_", "observableAndroidActivities_", "cachedWebviewFilesConfiguration_", "defaultShowCompletionState_", "downloadPolicy_", "debugSettings_", "maxExtrasSizeKb_", "maxReceiptSizeMb_", "overwriteIntentFlagActivity_", "observableViewControllers_", "monitoringIds_", "levelPlayAppKey_", "accelerometerCollection_", "optimisticInitDelayMs_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<NativeConfiguration> parser2 = PARSER;
                    if (parser2 != null) {
                        return parser2;
                    }
                    synchronized (NativeConfiguration.class) {
                        parser = PARSER;
                        if (parser == null) {
                            parser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                            PARSER = parser;
                        }
                    }
                    return parser;
                case 6:
                    return (byte) 1;
                default:
                    C0950f.m10573c();
                case 7:
                    return null;
            }
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public AccelerometerCollectionConfiguration getAccelerometerCollection() {
            AccelerometerCollectionConfiguration accelerometerCollectionConfiguration = this.accelerometerCollection_;
            return accelerometerCollectionConfiguration == null ? AccelerometerCollectionConfiguration.getDefaultInstance() : accelerometerCollectionConfiguration;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public AdOperationsConfiguration getAdOperations() {
            AdOperationsConfiguration adOperationsConfiguration = this.adOperations_;
            return adOperationsConfiguration == null ? AdOperationsConfiguration.getDefaultInstance() : adOperationsConfiguration;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public RequestPolicy getAdPolicy() {
            RequestPolicy requestPolicy = this.adPolicy_;
            return requestPolicy == null ? RequestPolicy.getDefaultInstance() : requestPolicy;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public String getAdditionalStorePackages(int i) {
            return this.additionalStorePackages_.get(i);
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public ByteString getAdditionalStorePackagesBytes(int i) {
            return ByteString.copyFromUtf8(this.additionalStorePackages_.get(i));
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public int getAdditionalStorePackagesCount() {
            return this.additionalStorePackages_.size();
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public List<String> getAdditionalStorePackagesList() {
            return this.additionalStorePackages_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public CachedAssetsConfiguration getCachedAssetsConfiguration() {
            CachedAssetsConfiguration cachedAssetsConfiguration = this.cachedAssetsConfiguration_;
            return cachedAssetsConfiguration == null ? CachedAssetsConfiguration.getDefaultInstance() : cachedAssetsConfiguration;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public CachedAssetsConfiguration getCachedWebviewFilesConfiguration() {
            CachedAssetsConfiguration cachedAssetsConfiguration = this.cachedWebviewFilesConfiguration_;
            return cachedAssetsConfiguration == null ? CachedAssetsConfiguration.getDefaultInstance() : cachedAssetsConfiguration;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public DebugSettings getDebugSettings() {
            DebugSettings debugSettings = this.debugSettings_;
            return debugSettings == null ? DebugSettings.getDefaultInstance() : debugSettings;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public ShowCompletionState getDefaultShowCompletionState() {
            ShowCompletionState forNumber = ShowCompletionState.forNumber(this.defaultShowCompletionState_);
            return forNumber == null ? ShowCompletionState.UNRECOGNIZED : forNumber;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public int getDefaultShowCompletionStateValue() {
            return this.defaultShowCompletionState_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public DiagnosticEventsConfiguration getDiagnosticEvents() {
            DiagnosticEventsConfiguration diagnosticEventsConfiguration = this.diagnosticEvents_;
            return diagnosticEventsConfiguration == null ? DiagnosticEventsConfiguration.getDefaultInstance() : diagnosticEventsConfiguration;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public RequestPolicy getDownloadPolicy() {
            RequestPolicy requestPolicy = this.downloadPolicy_;
            return requestPolicy == null ? RequestPolicy.getDefaultInstance() : requestPolicy;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public boolean getEnableIapEvent() {
            return this.enableIapEvent_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public boolean getEnableOm() {
            return this.enableOm_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public FeatureFlags getFeatureFlags() {
            FeatureFlags featureFlags = this.featureFlags_;
            return featureFlags == null ? FeatureFlags.getDefaultInstance() : featureFlags;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public RequestPolicy getInitPolicy() {
            RequestPolicy requestPolicy = this.initPolicy_;
            return requestPolicy == null ? RequestPolicy.getDefaultInstance() : requestPolicy;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public String getLevelPlayAppKey() {
            return this.levelPlayAppKey_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public ByteString getLevelPlayAppKeyBytes() {
            return ByteString.copyFromUtf8(this.levelPlayAppKey_);
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public int getMaxExtrasSizeKb() {
            return this.maxExtrasSizeKb_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public int getMaxReceiptSizeMb() {
            return this.maxReceiptSizeMb_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public int getMonitoringIds(int i) {
            return this.monitoringIds_.getInt(i);
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public int getMonitoringIdsCount() {
            return this.monitoringIds_.size();
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public List<Integer> getMonitoringIdsList() {
            return this.monitoringIds_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public ByteString getObservableAndroidActivities(int i) {
            return this.observableAndroidActivities_.get(i);
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public int getObservableAndroidActivitiesCount() {
            return this.observableAndroidActivities_.size();
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public List<ByteString> getObservableAndroidActivitiesList() {
            return this.observableAndroidActivities_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public ByteString getObservableViewControllers(int i) {
            return this.observableViewControllers_.get(i);
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public int getObservableViewControllersCount() {
            return this.observableViewControllers_.size();
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public List<ByteString> getObservableViewControllersList() {
            return this.observableViewControllers_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public RequestPolicy getOperativeEventPolicy() {
            RequestPolicy requestPolicy = this.operativeEventPolicy_;
            return requestPolicy == null ? RequestPolicy.getDefaultInstance() : requestPolicy;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public int getOptimisticInitDelayMs() {
            return this.optimisticInitDelayMs_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public RequestPolicy getOtherPolicy() {
            RequestPolicy requestPolicy = this.otherPolicy_;
            return requestPolicy == null ? RequestPolicy.getDefaultInstance() : requestPolicy;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public int getOverwriteIntentFlagActivity() {
            return this.overwriteIntentFlagActivity_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public boolean hasAccelerometerCollection() {
            return (this.bitField0_ & 4096) != 0;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public boolean hasAdOperations() {
            return (this.bitField0_ & 32) != 0;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public boolean hasAdPolicy() {
            return (this.bitField0_ & 4) != 0;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public boolean hasCachedAssetsConfiguration() {
            return (this.bitField0_ & 128) != 0;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public boolean hasCachedWebviewFilesConfiguration() {
            return (this.bitField0_ & 256) != 0;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public boolean hasDebugSettings() {
            return (this.bitField0_ & 1024) != 0;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public boolean hasDiagnosticEvents() {
            return (this.bitField0_ & 1) != 0;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public boolean hasDownloadPolicy() {
            return (this.bitField0_ & 512) != 0;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public boolean hasFeatureFlags() {
            return (this.bitField0_ & 64) != 0;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public boolean hasInitPolicy() {
            return (this.bitField0_ & 2) != 0;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public boolean hasLevelPlayAppKey() {
            return (this.bitField0_ & 2048) != 0;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public boolean hasOperativeEventPolicy() {
            return (this.bitField0_ & 8) != 0;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public boolean hasOptimisticInitDelayMs() {
            return (this.bitField0_ & Segment.SIZE) != 0;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
        public boolean hasOtherPolicy() {
            return (this.bitField0_ & 16) != 0;
        }

        /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
        public static final class Builder extends GeneratedMessageLite.Builder<NativeConfiguration, Builder> implements NativeConfigurationOrBuilder {
            private Builder() {
                super(NativeConfiguration.DEFAULT_INSTANCE);
            }

            public Builder addAdditionalStorePackages(String str) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).addAdditionalStorePackages(str);
                return this;
            }

            public Builder addAdditionalStorePackagesBytes(ByteString byteString) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).addAdditionalStorePackagesBytes(byteString);
                return this;
            }

            public Builder addAllAdditionalStorePackages(Iterable<String> iterable) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).addAllAdditionalStorePackages(iterable);
                return this;
            }

            public Builder addAllMonitoringIds(Iterable<? extends Integer> iterable) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).addAllMonitoringIds(iterable);
                return this;
            }

            public Builder addAllObservableAndroidActivities(Iterable<? extends ByteString> iterable) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).addAllObservableAndroidActivities(iterable);
                return this;
            }

            public Builder addAllObservableViewControllers(Iterable<? extends ByteString> iterable) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).addAllObservableViewControllers(iterable);
                return this;
            }

            public Builder addMonitoringIds(int i) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).addMonitoringIds(i);
                return this;
            }

            public Builder addObservableAndroidActivities(ByteString byteString) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).addObservableAndroidActivities(byteString);
                return this;
            }

            public Builder addObservableViewControllers(ByteString byteString) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).addObservableViewControllers(byteString);
                return this;
            }

            public Builder clearAccelerometerCollection() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearAccelerometerCollection();
                return this;
            }

            public Builder clearAdOperations() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearAdOperations();
                return this;
            }

            public Builder clearAdPolicy() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearAdPolicy();
                return this;
            }

            public Builder clearAdditionalStorePackages() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearAdditionalStorePackages();
                return this;
            }

            public Builder clearCachedAssetsConfiguration() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearCachedAssetsConfiguration();
                return this;
            }

            public Builder clearCachedWebviewFilesConfiguration() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearCachedWebviewFilesConfiguration();
                return this;
            }

            public Builder clearDebugSettings() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearDebugSettings();
                return this;
            }

            public Builder clearDefaultShowCompletionState() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearDefaultShowCompletionState();
                return this;
            }

            public Builder clearDiagnosticEvents() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearDiagnosticEvents();
                return this;
            }

            public Builder clearDownloadPolicy() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearDownloadPolicy();
                return this;
            }

            public Builder clearEnableIapEvent() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearEnableIapEvent();
                return this;
            }

            public Builder clearEnableOm() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearEnableOm();
                return this;
            }

            public Builder clearFeatureFlags() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearFeatureFlags();
                return this;
            }

            public Builder clearInitPolicy() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearInitPolicy();
                return this;
            }

            public Builder clearLevelPlayAppKey() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearLevelPlayAppKey();
                return this;
            }

            public Builder clearMaxExtrasSizeKb() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearMaxExtrasSizeKb();
                return this;
            }

            public Builder clearMaxReceiptSizeMb() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearMaxReceiptSizeMb();
                return this;
            }

            public Builder clearMonitoringIds() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearMonitoringIds();
                return this;
            }

            public Builder clearObservableAndroidActivities() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearObservableAndroidActivities();
                return this;
            }

            public Builder clearObservableViewControllers() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearObservableViewControllers();
                return this;
            }

            public Builder clearOperativeEventPolicy() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearOperativeEventPolicy();
                return this;
            }

            public Builder clearOptimisticInitDelayMs() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearOptimisticInitDelayMs();
                return this;
            }

            public Builder clearOtherPolicy() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearOtherPolicy();
                return this;
            }

            public Builder clearOverwriteIntentFlagActivity() {
                copyOnWrite();
                ((NativeConfiguration) this.instance).clearOverwriteIntentFlagActivity();
                return this;
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public AccelerometerCollectionConfiguration getAccelerometerCollection() {
                return ((NativeConfiguration) this.instance).getAccelerometerCollection();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public AdOperationsConfiguration getAdOperations() {
                return ((NativeConfiguration) this.instance).getAdOperations();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public RequestPolicy getAdPolicy() {
                return ((NativeConfiguration) this.instance).getAdPolicy();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public String getAdditionalStorePackages(int i) {
                return ((NativeConfiguration) this.instance).getAdditionalStorePackages(i);
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public ByteString getAdditionalStorePackagesBytes(int i) {
                return ((NativeConfiguration) this.instance).getAdditionalStorePackagesBytes(i);
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public int getAdditionalStorePackagesCount() {
                return ((NativeConfiguration) this.instance).getAdditionalStorePackagesCount();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public List<String> getAdditionalStorePackagesList() {
                return Collections.unmodifiableList(((NativeConfiguration) this.instance).getAdditionalStorePackagesList());
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public CachedAssetsConfiguration getCachedAssetsConfiguration() {
                return ((NativeConfiguration) this.instance).getCachedAssetsConfiguration();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public CachedAssetsConfiguration getCachedWebviewFilesConfiguration() {
                return ((NativeConfiguration) this.instance).getCachedWebviewFilesConfiguration();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public DebugSettings getDebugSettings() {
                return ((NativeConfiguration) this.instance).getDebugSettings();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public ShowCompletionState getDefaultShowCompletionState() {
                return ((NativeConfiguration) this.instance).getDefaultShowCompletionState();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public int getDefaultShowCompletionStateValue() {
                return ((NativeConfiguration) this.instance).getDefaultShowCompletionStateValue();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public DiagnosticEventsConfiguration getDiagnosticEvents() {
                return ((NativeConfiguration) this.instance).getDiagnosticEvents();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public RequestPolicy getDownloadPolicy() {
                return ((NativeConfiguration) this.instance).getDownloadPolicy();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public boolean getEnableIapEvent() {
                return ((NativeConfiguration) this.instance).getEnableIapEvent();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public boolean getEnableOm() {
                return ((NativeConfiguration) this.instance).getEnableOm();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public FeatureFlags getFeatureFlags() {
                return ((NativeConfiguration) this.instance).getFeatureFlags();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public RequestPolicy getInitPolicy() {
                return ((NativeConfiguration) this.instance).getInitPolicy();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public String getLevelPlayAppKey() {
                return ((NativeConfiguration) this.instance).getLevelPlayAppKey();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public ByteString getLevelPlayAppKeyBytes() {
                return ((NativeConfiguration) this.instance).getLevelPlayAppKeyBytes();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public int getMaxExtrasSizeKb() {
                return ((NativeConfiguration) this.instance).getMaxExtrasSizeKb();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public int getMaxReceiptSizeMb() {
                return ((NativeConfiguration) this.instance).getMaxReceiptSizeMb();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public int getMonitoringIds(int i) {
                return ((NativeConfiguration) this.instance).getMonitoringIds(i);
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public int getMonitoringIdsCount() {
                return ((NativeConfiguration) this.instance).getMonitoringIdsCount();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public List<Integer> getMonitoringIdsList() {
                return Collections.unmodifiableList(((NativeConfiguration) this.instance).getMonitoringIdsList());
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public ByteString getObservableAndroidActivities(int i) {
                return ((NativeConfiguration) this.instance).getObservableAndroidActivities(i);
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public int getObservableAndroidActivitiesCount() {
                return ((NativeConfiguration) this.instance).getObservableAndroidActivitiesCount();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public List<ByteString> getObservableAndroidActivitiesList() {
                return Collections.unmodifiableList(((NativeConfiguration) this.instance).getObservableAndroidActivitiesList());
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public ByteString getObservableViewControllers(int i) {
                return ((NativeConfiguration) this.instance).getObservableViewControllers(i);
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public int getObservableViewControllersCount() {
                return ((NativeConfiguration) this.instance).getObservableViewControllersCount();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public List<ByteString> getObservableViewControllersList() {
                return Collections.unmodifiableList(((NativeConfiguration) this.instance).getObservableViewControllersList());
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public RequestPolicy getOperativeEventPolicy() {
                return ((NativeConfiguration) this.instance).getOperativeEventPolicy();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public int getOptimisticInitDelayMs() {
                return ((NativeConfiguration) this.instance).getOptimisticInitDelayMs();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public RequestPolicy getOtherPolicy() {
                return ((NativeConfiguration) this.instance).getOtherPolicy();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public int getOverwriteIntentFlagActivity() {
                return ((NativeConfiguration) this.instance).getOverwriteIntentFlagActivity();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public boolean hasAccelerometerCollection() {
                return ((NativeConfiguration) this.instance).hasAccelerometerCollection();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public boolean hasAdOperations() {
                return ((NativeConfiguration) this.instance).hasAdOperations();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public boolean hasAdPolicy() {
                return ((NativeConfiguration) this.instance).hasAdPolicy();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public boolean hasCachedAssetsConfiguration() {
                return ((NativeConfiguration) this.instance).hasCachedAssetsConfiguration();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public boolean hasCachedWebviewFilesConfiguration() {
                return ((NativeConfiguration) this.instance).hasCachedWebviewFilesConfiguration();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public boolean hasDebugSettings() {
                return ((NativeConfiguration) this.instance).hasDebugSettings();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public boolean hasDiagnosticEvents() {
                return ((NativeConfiguration) this.instance).hasDiagnosticEvents();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public boolean hasDownloadPolicy() {
                return ((NativeConfiguration) this.instance).hasDownloadPolicy();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public boolean hasFeatureFlags() {
                return ((NativeConfiguration) this.instance).hasFeatureFlags();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public boolean hasInitPolicy() {
                return ((NativeConfiguration) this.instance).hasInitPolicy();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public boolean hasLevelPlayAppKey() {
                return ((NativeConfiguration) this.instance).hasLevelPlayAppKey();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public boolean hasOperativeEventPolicy() {
                return ((NativeConfiguration) this.instance).hasOperativeEventPolicy();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public boolean hasOptimisticInitDelayMs() {
                return ((NativeConfiguration) this.instance).hasOptimisticInitDelayMs();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfigurationOrBuilder
            public boolean hasOtherPolicy() {
                return ((NativeConfiguration) this.instance).hasOtherPolicy();
            }

            public Builder mergeAccelerometerCollection(AccelerometerCollectionConfiguration accelerometerCollectionConfiguration) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).mergeAccelerometerCollection(accelerometerCollectionConfiguration);
                return this;
            }

            public Builder mergeAdOperations(AdOperationsConfiguration adOperationsConfiguration) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).mergeAdOperations(adOperationsConfiguration);
                return this;
            }

            public Builder mergeAdPolicy(RequestPolicy requestPolicy) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).mergeAdPolicy(requestPolicy);
                return this;
            }

            public Builder mergeCachedAssetsConfiguration(CachedAssetsConfiguration cachedAssetsConfiguration) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).mergeCachedAssetsConfiguration(cachedAssetsConfiguration);
                return this;
            }

            public Builder mergeCachedWebviewFilesConfiguration(CachedAssetsConfiguration cachedAssetsConfiguration) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).mergeCachedWebviewFilesConfiguration(cachedAssetsConfiguration);
                return this;
            }

            public Builder mergeDebugSettings(DebugSettings debugSettings) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).mergeDebugSettings(debugSettings);
                return this;
            }

            public Builder mergeDiagnosticEvents(DiagnosticEventsConfiguration diagnosticEventsConfiguration) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).mergeDiagnosticEvents(diagnosticEventsConfiguration);
                return this;
            }

            public Builder mergeDownloadPolicy(RequestPolicy requestPolicy) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).mergeDownloadPolicy(requestPolicy);
                return this;
            }

            public Builder mergeFeatureFlags(FeatureFlags featureFlags) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).mergeFeatureFlags(featureFlags);
                return this;
            }

            public Builder mergeInitPolicy(RequestPolicy requestPolicy) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).mergeInitPolicy(requestPolicy);
                return this;
            }

            public Builder mergeOperativeEventPolicy(RequestPolicy requestPolicy) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).mergeOperativeEventPolicy(requestPolicy);
                return this;
            }

            public Builder mergeOtherPolicy(RequestPolicy requestPolicy) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).mergeOtherPolicy(requestPolicy);
                return this;
            }

            public Builder setAccelerometerCollection(AccelerometerCollectionConfiguration.Builder builder) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setAccelerometerCollection(builder.build());
                return this;
            }

            public Builder setAdOperations(AdOperationsConfiguration.Builder builder) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setAdOperations(builder.build());
                return this;
            }

            public Builder setAdPolicy(RequestPolicy.Builder builder) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setAdPolicy(builder.build());
                return this;
            }

            public Builder setAdditionalStorePackages(int i, String str) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setAdditionalStorePackages(i, str);
                return this;
            }

            public Builder setCachedAssetsConfiguration(CachedAssetsConfiguration.Builder builder) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setCachedAssetsConfiguration(builder.build());
                return this;
            }

            public Builder setCachedWebviewFilesConfiguration(CachedAssetsConfiguration.Builder builder) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setCachedWebviewFilesConfiguration(builder.build());
                return this;
            }

            public Builder setDebugSettings(DebugSettings.Builder builder) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setDebugSettings(builder.build());
                return this;
            }

            public Builder setDefaultShowCompletionState(ShowCompletionState showCompletionState) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setDefaultShowCompletionState(showCompletionState);
                return this;
            }

            public Builder setDefaultShowCompletionStateValue(int i) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setDefaultShowCompletionStateValue(i);
                return this;
            }

            public Builder setDiagnosticEvents(DiagnosticEventsConfiguration.Builder builder) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setDiagnosticEvents(builder.build());
                return this;
            }

            public Builder setDownloadPolicy(RequestPolicy.Builder builder) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setDownloadPolicy(builder.build());
                return this;
            }

            public Builder setEnableIapEvent(boolean z) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setEnableIapEvent(z);
                return this;
            }

            public Builder setEnableOm(boolean z) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setEnableOm(z);
                return this;
            }

            public Builder setFeatureFlags(FeatureFlags.Builder builder) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setFeatureFlags(builder.build());
                return this;
            }

            public Builder setInitPolicy(RequestPolicy.Builder builder) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setInitPolicy(builder.build());
                return this;
            }

            public Builder setLevelPlayAppKey(String str) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setLevelPlayAppKey(str);
                return this;
            }

            public Builder setLevelPlayAppKeyBytes(ByteString byteString) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setLevelPlayAppKeyBytes(byteString);
                return this;
            }

            public Builder setMaxExtrasSizeKb(int i) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setMaxExtrasSizeKb(i);
                return this;
            }

            public Builder setMaxReceiptSizeMb(int i) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setMaxReceiptSizeMb(i);
                return this;
            }

            public Builder setMonitoringIds(int i, int i2) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setMonitoringIds(i, i2);
                return this;
            }

            public Builder setObservableAndroidActivities(int i, ByteString byteString) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setObservableAndroidActivities(i, byteString);
                return this;
            }

            public Builder setObservableViewControllers(int i, ByteString byteString) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setObservableViewControllers(i, byteString);
                return this;
            }

            public Builder setOperativeEventPolicy(RequestPolicy.Builder builder) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setOperativeEventPolicy(builder.build());
                return this;
            }

            public Builder setOptimisticInitDelayMs(int i) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setOptimisticInitDelayMs(i);
                return this;
            }

            public Builder setOtherPolicy(RequestPolicy.Builder builder) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setOtherPolicy(builder.build());
                return this;
            }

            public Builder setOverwriteIntentFlagActivity(int i) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setOverwriteIntentFlagActivity(i);
                return this;
            }

            public /* synthetic */ Builder(fg3 fg3Var) {
                this();
            }

            public Builder setAccelerometerCollection(AccelerometerCollectionConfiguration accelerometerCollectionConfiguration) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setAccelerometerCollection(accelerometerCollectionConfiguration);
                return this;
            }

            public Builder setAdOperations(AdOperationsConfiguration adOperationsConfiguration) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setAdOperations(adOperationsConfiguration);
                return this;
            }

            public Builder setAdPolicy(RequestPolicy requestPolicy) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setAdPolicy(requestPolicy);
                return this;
            }

            public Builder setCachedAssetsConfiguration(CachedAssetsConfiguration cachedAssetsConfiguration) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setCachedAssetsConfiguration(cachedAssetsConfiguration);
                return this;
            }

            public Builder setCachedWebviewFilesConfiguration(CachedAssetsConfiguration cachedAssetsConfiguration) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setCachedWebviewFilesConfiguration(cachedAssetsConfiguration);
                return this;
            }

            public Builder setDebugSettings(DebugSettings debugSettings) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setDebugSettings(debugSettings);
                return this;
            }

            public Builder setDiagnosticEvents(DiagnosticEventsConfiguration diagnosticEventsConfiguration) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setDiagnosticEvents(diagnosticEventsConfiguration);
                return this;
            }

            public Builder setDownloadPolicy(RequestPolicy requestPolicy) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setDownloadPolicy(requestPolicy);
                return this;
            }

            public Builder setFeatureFlags(FeatureFlags featureFlags) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setFeatureFlags(featureFlags);
                return this;
            }

            public Builder setInitPolicy(RequestPolicy requestPolicy) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setInitPolicy(requestPolicy);
                return this;
            }

            public Builder setOperativeEventPolicy(RequestPolicy requestPolicy) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setOperativeEventPolicy(requestPolicy);
                return this;
            }

            public Builder setOtherPolicy(RequestPolicy requestPolicy) {
                copyOnWrite();
                ((NativeConfiguration) this.instance).setOtherPolicy(requestPolicy);
                return this;
            }
        }

        public static Builder newBuilder(NativeConfiguration nativeConfiguration) {
            return DEFAULT_INSTANCE.createBuilder(nativeConfiguration);
        }

        public static NativeConfiguration parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (NativeConfiguration) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static NativeConfiguration parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (NativeConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static NativeConfiguration parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return (NativeConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static NativeConfiguration parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (NativeConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static NativeConfiguration parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return (NativeConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static NativeConfiguration parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (NativeConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static NativeConfiguration parseFrom(InputStream inputStream) throws IOException {
            return (NativeConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static NativeConfiguration parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (NativeConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static NativeConfiguration parseFrom(CodedInputStream codedInputStream) throws IOException {
            return (NativeConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static NativeConfiguration parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (NativeConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public static final class RequestPolicy extends GeneratedMessageLite<RequestPolicy, Builder> implements RequestPolicyOrBuilder {
        private static final RequestPolicy DEFAULT_INSTANCE;
        private static volatile Parser<RequestPolicy> PARSER = null;
        public static final int RETRY_POLICY_FIELD_NUMBER = 1;
        public static final int TIMEOUT_POLICY_FIELD_NUMBER = 2;
        private int bitField0_;
        private RequestRetryPolicy retryPolicy_;
        private RequestTimeoutPolicy timeoutPolicy_;

        static {
            RequestPolicy requestPolicy = new RequestPolicy();
            DEFAULT_INSTANCE = requestPolicy;
            GeneratedMessageLite.registerDefaultInstance(RequestPolicy.class, requestPolicy);
        }

        private RequestPolicy() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearRetryPolicy() {
            this.retryPolicy_ = null;
            this.bitField0_ &= -2;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearTimeoutPolicy() {
            this.timeoutPolicy_ = null;
            this.bitField0_ &= -3;
        }

        public static RequestPolicy getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void mergeRetryPolicy(RequestRetryPolicy requestRetryPolicy) {
            requestRetryPolicy.getClass();
            RequestRetryPolicy requestRetryPolicy2 = this.retryPolicy_;
            if (requestRetryPolicy2 == null || requestRetryPolicy2 == RequestRetryPolicy.getDefaultInstance()) {
                this.retryPolicy_ = requestRetryPolicy;
            } else {
                this.retryPolicy_ = RequestRetryPolicy.newBuilder(this.retryPolicy_).mergeFrom((RequestRetryPolicy.Builder) requestRetryPolicy).buildPartial();
            }
            this.bitField0_ |= 1;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void mergeTimeoutPolicy(RequestTimeoutPolicy requestTimeoutPolicy) {
            requestTimeoutPolicy.getClass();
            RequestTimeoutPolicy requestTimeoutPolicy2 = this.timeoutPolicy_;
            if (requestTimeoutPolicy2 == null || requestTimeoutPolicy2 == RequestTimeoutPolicy.getDefaultInstance()) {
                this.timeoutPolicy_ = requestTimeoutPolicy;
            } else {
                this.timeoutPolicy_ = RequestTimeoutPolicy.newBuilder(this.timeoutPolicy_).mergeFrom((RequestTimeoutPolicy.Builder) requestTimeoutPolicy).buildPartial();
            }
            this.bitField0_ |= 2;
        }

        public static Builder newBuilder() {
            return DEFAULT_INSTANCE.createBuilder();
        }

        public static RequestPolicy parseDelimitedFrom(InputStream inputStream) throws IOException {
            return (RequestPolicy) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RequestPolicy parseFrom(ByteBuffer byteBuffer) throws InvalidProtocolBufferException {
            return (RequestPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RequestPolicy> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setRetryPolicy(RequestRetryPolicy requestRetryPolicy) {
            requestRetryPolicy.getClass();
            this.retryPolicy_ = requestRetryPolicy;
            this.bitField0_ |= 1;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setTimeoutPolicy(RequestTimeoutPolicy requestTimeoutPolicy) {
            requestTimeoutPolicy.getClass();
            this.timeoutPolicy_ = requestTimeoutPolicy;
            this.bitField0_ |= 2;
        }

        @Override // com.google.protobuf.GeneratedMessageLite
        public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            Parser parser;
            int i = fg3.f13801a[methodToInvoke.ordinal()];
            fg3 fg3Var = null;
            switch (i) {
                case 1:
                    return new RequestPolicy();
                case 2:
                    return new Builder(fg3Var);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001ဉ\u0000\u0002ဉ\u0001", new Object[]{"bitField0_", "retryPolicy_", "timeoutPolicy_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RequestPolicy> parser2 = PARSER;
                    if (parser2 != null) {
                        return parser2;
                    }
                    synchronized (RequestPolicy.class) {
                        parser = PARSER;
                        if (parser == null) {
                            parser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                            PARSER = parser;
                        }
                    }
                    return parser;
                case 6:
                    return (byte) 1;
                default:
                    C0950f.m10573c();
                case 7:
                    return null;
            }
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestPolicyOrBuilder
        public RequestRetryPolicy getRetryPolicy() {
            RequestRetryPolicy requestRetryPolicy = this.retryPolicy_;
            return requestRetryPolicy == null ? RequestRetryPolicy.getDefaultInstance() : requestRetryPolicy;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestPolicyOrBuilder
        public RequestTimeoutPolicy getTimeoutPolicy() {
            RequestTimeoutPolicy requestTimeoutPolicy = this.timeoutPolicy_;
            return requestTimeoutPolicy == null ? RequestTimeoutPolicy.getDefaultInstance() : requestTimeoutPolicy;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestPolicyOrBuilder
        public boolean hasRetryPolicy() {
            return (this.bitField0_ & 1) != 0;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestPolicyOrBuilder
        public boolean hasTimeoutPolicy() {
            return (this.bitField0_ & 2) != 0;
        }

        /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
        public static final class Builder extends GeneratedMessageLite.Builder<RequestPolicy, Builder> implements RequestPolicyOrBuilder {
            private Builder() {
                super(RequestPolicy.DEFAULT_INSTANCE);
            }

            public Builder clearRetryPolicy() {
                copyOnWrite();
                ((RequestPolicy) this.instance).clearRetryPolicy();
                return this;
            }

            public Builder clearTimeoutPolicy() {
                copyOnWrite();
                ((RequestPolicy) this.instance).clearTimeoutPolicy();
                return this;
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestPolicyOrBuilder
            public RequestRetryPolicy getRetryPolicy() {
                return ((RequestPolicy) this.instance).getRetryPolicy();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestPolicyOrBuilder
            public RequestTimeoutPolicy getTimeoutPolicy() {
                return ((RequestPolicy) this.instance).getTimeoutPolicy();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestPolicyOrBuilder
            public boolean hasRetryPolicy() {
                return ((RequestPolicy) this.instance).hasRetryPolicy();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestPolicyOrBuilder
            public boolean hasTimeoutPolicy() {
                return ((RequestPolicy) this.instance).hasTimeoutPolicy();
            }

            public Builder mergeRetryPolicy(RequestRetryPolicy requestRetryPolicy) {
                copyOnWrite();
                ((RequestPolicy) this.instance).mergeRetryPolicy(requestRetryPolicy);
                return this;
            }

            public Builder mergeTimeoutPolicy(RequestTimeoutPolicy requestTimeoutPolicy) {
                copyOnWrite();
                ((RequestPolicy) this.instance).mergeTimeoutPolicy(requestTimeoutPolicy);
                return this;
            }

            public Builder setRetryPolicy(RequestRetryPolicy.Builder builder) {
                copyOnWrite();
                ((RequestPolicy) this.instance).setRetryPolicy(builder.build());
                return this;
            }

            public Builder setTimeoutPolicy(RequestTimeoutPolicy.Builder builder) {
                copyOnWrite();
                ((RequestPolicy) this.instance).setTimeoutPolicy(builder.build());
                return this;
            }

            public /* synthetic */ Builder(fg3 fg3Var) {
                this();
            }

            public Builder setRetryPolicy(RequestRetryPolicy requestRetryPolicy) {
                copyOnWrite();
                ((RequestPolicy) this.instance).setRetryPolicy(requestRetryPolicy);
                return this;
            }

            public Builder setTimeoutPolicy(RequestTimeoutPolicy requestTimeoutPolicy) {
                copyOnWrite();
                ((RequestPolicy) this.instance).setTimeoutPolicy(requestTimeoutPolicy);
                return this;
            }
        }

        public static Builder newBuilder(RequestPolicy requestPolicy) {
            return DEFAULT_INSTANCE.createBuilder(requestPolicy);
        }

        public static RequestPolicy parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (RequestPolicy) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RequestPolicy parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (RequestPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RequestPolicy parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return (RequestPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RequestPolicy parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (RequestPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RequestPolicy parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return (RequestPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RequestPolicy parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (RequestPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RequestPolicy parseFrom(InputStream inputStream) throws IOException {
            return (RequestPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RequestPolicy parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (RequestPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RequestPolicy parseFrom(CodedInputStream codedInputStream) throws IOException {
            return (RequestPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RequestPolicy parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (RequestPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public static final class RequestRetryPolicy extends GeneratedMessageLite<RequestRetryPolicy, Builder> implements RequestRetryPolicyOrBuilder {
        private static final RequestRetryPolicy DEFAULT_INSTANCE;
        public static final int MAX_DURATION_FIELD_NUMBER = 1;
        private static volatile Parser<RequestRetryPolicy> PARSER = null;
        public static final int RETRY_JITTER_PCT_FIELD_NUMBER = 4;
        public static final int RETRY_MAX_INTERVAL_FIELD_NUMBER = 3;
        public static final int RETRY_SCALING_FACTOR_FIELD_NUMBER = 5;
        public static final int RETRY_WAIT_BASE_FIELD_NUMBER = 2;
        public static final int SHOULD_STORE_LOCALLY_FIELD_NUMBER = 6;
        private int maxDuration_;
        private float retryJitterPct_;
        private int retryMaxInterval_;
        private float retryScalingFactor_;
        private int retryWaitBase_;
        private boolean shouldStoreLocally_;

        static {
            RequestRetryPolicy requestRetryPolicy = new RequestRetryPolicy();
            DEFAULT_INSTANCE = requestRetryPolicy;
            GeneratedMessageLite.registerDefaultInstance(RequestRetryPolicy.class, requestRetryPolicy);
        }

        private RequestRetryPolicy() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearMaxDuration() {
            this.maxDuration_ = 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearRetryJitterPct() {
            this.retryJitterPct_ = 0.0f;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearRetryMaxInterval() {
            this.retryMaxInterval_ = 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearRetryScalingFactor() {
            this.retryScalingFactor_ = 0.0f;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearRetryWaitBase() {
            this.retryWaitBase_ = 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearShouldStoreLocally() {
            this.shouldStoreLocally_ = false;
        }

        public static RequestRetryPolicy getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return DEFAULT_INSTANCE.createBuilder();
        }

        public static RequestRetryPolicy parseDelimitedFrom(InputStream inputStream) throws IOException {
            return (RequestRetryPolicy) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RequestRetryPolicy parseFrom(ByteBuffer byteBuffer) throws InvalidProtocolBufferException {
            return (RequestRetryPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RequestRetryPolicy> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setMaxDuration(int i) {
            this.maxDuration_ = i;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setRetryJitterPct(float f) {
            this.retryJitterPct_ = f;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setRetryMaxInterval(int i) {
            this.retryMaxInterval_ = i;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setRetryScalingFactor(float f) {
            this.retryScalingFactor_ = f;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setRetryWaitBase(int i) {
            this.retryWaitBase_ = i;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setShouldStoreLocally(boolean z) {
            this.shouldStoreLocally_ = z;
        }

        @Override // com.google.protobuf.GeneratedMessageLite
        public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            Parser parser;
            int i = fg3.f13801a[methodToInvoke.ordinal()];
            fg3 fg3Var = null;
            switch (i) {
                case 1:
                    return new RequestRetryPolicy();
                case 2:
                    return new Builder(fg3Var);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0006\u0000\u0000\u0001\u0006\u0006\u0000\u0000\u0000\u0001\u0004\u0002\u0004\u0003\u0004\u0004\u0001\u0005\u0001\u0006\u0007", new Object[]{"maxDuration_", "retryWaitBase_", "retryMaxInterval_", "retryJitterPct_", "retryScalingFactor_", "shouldStoreLocally_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RequestRetryPolicy> parser2 = PARSER;
                    if (parser2 != null) {
                        return parser2;
                    }
                    synchronized (RequestRetryPolicy.class) {
                        parser = PARSER;
                        if (parser == null) {
                            parser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                            PARSER = parser;
                        }
                    }
                    return parser;
                case 6:
                    return (byte) 1;
                default:
                    C0950f.m10573c();
                case 7:
                    return null;
            }
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestRetryPolicyOrBuilder
        public int getMaxDuration() {
            return this.maxDuration_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestRetryPolicyOrBuilder
        public float getRetryJitterPct() {
            return this.retryJitterPct_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestRetryPolicyOrBuilder
        public int getRetryMaxInterval() {
            return this.retryMaxInterval_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestRetryPolicyOrBuilder
        public float getRetryScalingFactor() {
            return this.retryScalingFactor_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestRetryPolicyOrBuilder
        public int getRetryWaitBase() {
            return this.retryWaitBase_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestRetryPolicyOrBuilder
        public boolean getShouldStoreLocally() {
            return this.shouldStoreLocally_;
        }

        /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
        public static final class Builder extends GeneratedMessageLite.Builder<RequestRetryPolicy, Builder> implements RequestRetryPolicyOrBuilder {
            private Builder() {
                super(RequestRetryPolicy.DEFAULT_INSTANCE);
            }

            public Builder clearMaxDuration() {
                copyOnWrite();
                ((RequestRetryPolicy) this.instance).clearMaxDuration();
                return this;
            }

            public Builder clearRetryJitterPct() {
                copyOnWrite();
                ((RequestRetryPolicy) this.instance).clearRetryJitterPct();
                return this;
            }

            public Builder clearRetryMaxInterval() {
                copyOnWrite();
                ((RequestRetryPolicy) this.instance).clearRetryMaxInterval();
                return this;
            }

            public Builder clearRetryScalingFactor() {
                copyOnWrite();
                ((RequestRetryPolicy) this.instance).clearRetryScalingFactor();
                return this;
            }

            public Builder clearRetryWaitBase() {
                copyOnWrite();
                ((RequestRetryPolicy) this.instance).clearRetryWaitBase();
                return this;
            }

            public Builder clearShouldStoreLocally() {
                copyOnWrite();
                ((RequestRetryPolicy) this.instance).clearShouldStoreLocally();
                return this;
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestRetryPolicyOrBuilder
            public int getMaxDuration() {
                return ((RequestRetryPolicy) this.instance).getMaxDuration();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestRetryPolicyOrBuilder
            public float getRetryJitterPct() {
                return ((RequestRetryPolicy) this.instance).getRetryJitterPct();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestRetryPolicyOrBuilder
            public int getRetryMaxInterval() {
                return ((RequestRetryPolicy) this.instance).getRetryMaxInterval();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestRetryPolicyOrBuilder
            public float getRetryScalingFactor() {
                return ((RequestRetryPolicy) this.instance).getRetryScalingFactor();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestRetryPolicyOrBuilder
            public int getRetryWaitBase() {
                return ((RequestRetryPolicy) this.instance).getRetryWaitBase();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestRetryPolicyOrBuilder
            public boolean getShouldStoreLocally() {
                return ((RequestRetryPolicy) this.instance).getShouldStoreLocally();
            }

            public Builder setMaxDuration(int i) {
                copyOnWrite();
                ((RequestRetryPolicy) this.instance).setMaxDuration(i);
                return this;
            }

            public Builder setRetryJitterPct(float f) {
                copyOnWrite();
                ((RequestRetryPolicy) this.instance).setRetryJitterPct(f);
                return this;
            }

            public Builder setRetryMaxInterval(int i) {
                copyOnWrite();
                ((RequestRetryPolicy) this.instance).setRetryMaxInterval(i);
                return this;
            }

            public Builder setRetryScalingFactor(float f) {
                copyOnWrite();
                ((RequestRetryPolicy) this.instance).setRetryScalingFactor(f);
                return this;
            }

            public Builder setRetryWaitBase(int i) {
                copyOnWrite();
                ((RequestRetryPolicy) this.instance).setRetryWaitBase(i);
                return this;
            }

            public Builder setShouldStoreLocally(boolean z) {
                copyOnWrite();
                ((RequestRetryPolicy) this.instance).setShouldStoreLocally(z);
                return this;
            }

            public /* synthetic */ Builder(fg3 fg3Var) {
                this();
            }
        }

        public static Builder newBuilder(RequestRetryPolicy requestRetryPolicy) {
            return DEFAULT_INSTANCE.createBuilder(requestRetryPolicy);
        }

        public static RequestRetryPolicy parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (RequestRetryPolicy) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RequestRetryPolicy parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (RequestRetryPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RequestRetryPolicy parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return (RequestRetryPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RequestRetryPolicy parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (RequestRetryPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RequestRetryPolicy parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return (RequestRetryPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RequestRetryPolicy parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (RequestRetryPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RequestRetryPolicy parseFrom(InputStream inputStream) throws IOException {
            return (RequestRetryPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RequestRetryPolicy parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (RequestRetryPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RequestRetryPolicy parseFrom(CodedInputStream codedInputStream) throws IOException {
            return (RequestRetryPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RequestRetryPolicy parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (RequestRetryPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public static final class RequestTimeoutPolicy extends GeneratedMessageLite<RequestTimeoutPolicy, Builder> implements RequestTimeoutPolicyOrBuilder {
        public static final int CONNECT_TIMEOUT_MS_FIELD_NUMBER = 1;
        private static final RequestTimeoutPolicy DEFAULT_INSTANCE;
        public static final int OVERALL_TIMEOUT_MS_FIELD_NUMBER = 4;
        private static volatile Parser<RequestTimeoutPolicy> PARSER = null;
        public static final int READ_TIMEOUT_MS_FIELD_NUMBER = 2;
        public static final int WRITE_TIMEOUT_MS_FIELD_NUMBER = 3;
        private int connectTimeoutMs_;
        private int overallTimeoutMs_;
        private int readTimeoutMs_;
        private int writeTimeoutMs_;

        static {
            RequestTimeoutPolicy requestTimeoutPolicy = new RequestTimeoutPolicy();
            DEFAULT_INSTANCE = requestTimeoutPolicy;
            GeneratedMessageLite.registerDefaultInstance(RequestTimeoutPolicy.class, requestTimeoutPolicy);
        }

        private RequestTimeoutPolicy() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearConnectTimeoutMs() {
            this.connectTimeoutMs_ = 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearOverallTimeoutMs() {
            this.overallTimeoutMs_ = 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearReadTimeoutMs() {
            this.readTimeoutMs_ = 0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void clearWriteTimeoutMs() {
            this.writeTimeoutMs_ = 0;
        }

        public static RequestTimeoutPolicy getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return DEFAULT_INSTANCE.createBuilder();
        }

        public static RequestTimeoutPolicy parseDelimitedFrom(InputStream inputStream) throws IOException {
            return (RequestTimeoutPolicy) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RequestTimeoutPolicy parseFrom(ByteBuffer byteBuffer) throws InvalidProtocolBufferException {
            return (RequestTimeoutPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RequestTimeoutPolicy> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setConnectTimeoutMs(int i) {
            this.connectTimeoutMs_ = i;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setOverallTimeoutMs(int i) {
            this.overallTimeoutMs_ = i;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setReadTimeoutMs(int i) {
            this.readTimeoutMs_ = i;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setWriteTimeoutMs(int i) {
            this.writeTimeoutMs_ = i;
        }

        @Override // com.google.protobuf.GeneratedMessageLite
        public final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            Parser parser;
            int i = fg3.f13801a[methodToInvoke.ordinal()];
            fg3 fg3Var = null;
            switch (i) {
                case 1:
                    return new RequestTimeoutPolicy();
                case 2:
                    return new Builder(fg3Var);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001\u0004\u0002\u0004\u0003\u0004\u0004\u0004", new Object[]{"connectTimeoutMs_", "readTimeoutMs_", "writeTimeoutMs_", "overallTimeoutMs_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RequestTimeoutPolicy> parser2 = PARSER;
                    if (parser2 != null) {
                        return parser2;
                    }
                    synchronized (RequestTimeoutPolicy.class) {
                        parser = PARSER;
                        if (parser == null) {
                            parser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                            PARSER = parser;
                        }
                    }
                    return parser;
                case 6:
                    return (byte) 1;
                default:
                    C0950f.m10573c();
                case 7:
                    return null;
            }
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestTimeoutPolicyOrBuilder
        public int getConnectTimeoutMs() {
            return this.connectTimeoutMs_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestTimeoutPolicyOrBuilder
        public int getOverallTimeoutMs() {
            return this.overallTimeoutMs_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestTimeoutPolicyOrBuilder
        public int getReadTimeoutMs() {
            return this.readTimeoutMs_;
        }

        @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestTimeoutPolicyOrBuilder
        public int getWriteTimeoutMs() {
            return this.writeTimeoutMs_;
        }

        /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
        public static final class Builder extends GeneratedMessageLite.Builder<RequestTimeoutPolicy, Builder> implements RequestTimeoutPolicyOrBuilder {
            private Builder() {
                super(RequestTimeoutPolicy.DEFAULT_INSTANCE);
            }

            public Builder clearConnectTimeoutMs() {
                copyOnWrite();
                ((RequestTimeoutPolicy) this.instance).clearConnectTimeoutMs();
                return this;
            }

            public Builder clearOverallTimeoutMs() {
                copyOnWrite();
                ((RequestTimeoutPolicy) this.instance).clearOverallTimeoutMs();
                return this;
            }

            public Builder clearReadTimeoutMs() {
                copyOnWrite();
                ((RequestTimeoutPolicy) this.instance).clearReadTimeoutMs();
                return this;
            }

            public Builder clearWriteTimeoutMs() {
                copyOnWrite();
                ((RequestTimeoutPolicy) this.instance).clearWriteTimeoutMs();
                return this;
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestTimeoutPolicyOrBuilder
            public int getConnectTimeoutMs() {
                return ((RequestTimeoutPolicy) this.instance).getConnectTimeoutMs();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestTimeoutPolicyOrBuilder
            public int getOverallTimeoutMs() {
                return ((RequestTimeoutPolicy) this.instance).getOverallTimeoutMs();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestTimeoutPolicyOrBuilder
            public int getReadTimeoutMs() {
                return ((RequestTimeoutPolicy) this.instance).getReadTimeoutMs();
            }

            @Override // gatewayprotocol.v1.NativeConfigurationOuterClass.RequestTimeoutPolicyOrBuilder
            public int getWriteTimeoutMs() {
                return ((RequestTimeoutPolicy) this.instance).getWriteTimeoutMs();
            }

            public Builder setConnectTimeoutMs(int i) {
                copyOnWrite();
                ((RequestTimeoutPolicy) this.instance).setConnectTimeoutMs(i);
                return this;
            }

            public Builder setOverallTimeoutMs(int i) {
                copyOnWrite();
                ((RequestTimeoutPolicy) this.instance).setOverallTimeoutMs(i);
                return this;
            }

            public Builder setReadTimeoutMs(int i) {
                copyOnWrite();
                ((RequestTimeoutPolicy) this.instance).setReadTimeoutMs(i);
                return this;
            }

            public Builder setWriteTimeoutMs(int i) {
                copyOnWrite();
                ((RequestTimeoutPolicy) this.instance).setWriteTimeoutMs(i);
                return this;
            }

            public /* synthetic */ Builder(fg3 fg3Var) {
                this();
            }
        }

        public static Builder newBuilder(RequestTimeoutPolicy requestTimeoutPolicy) {
            return DEFAULT_INSTANCE.createBuilder(requestTimeoutPolicy);
        }

        public static RequestTimeoutPolicy parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (RequestTimeoutPolicy) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RequestTimeoutPolicy parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (RequestTimeoutPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RequestTimeoutPolicy parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return (RequestTimeoutPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RequestTimeoutPolicy parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (RequestTimeoutPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RequestTimeoutPolicy parseFrom(byte[] bArr) throws InvalidProtocolBufferException {
            return (RequestTimeoutPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RequestTimeoutPolicy parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (RequestTimeoutPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RequestTimeoutPolicy parseFrom(InputStream inputStream) throws IOException {
            return (RequestTimeoutPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RequestTimeoutPolicy parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (RequestTimeoutPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RequestTimeoutPolicy parseFrom(CodedInputStream codedInputStream) throws IOException {
            return (RequestTimeoutPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RequestTimeoutPolicy parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (RequestTimeoutPolicy) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public enum FullscreenNavBarMode implements Internal.EnumLite {
        FULLSCREEN_NAV_BAR_MODE_UNSPECIFIED(0),
        FULLSCREEN_NAV_BAR_MODE_TRANSPARENT(1),
        FULLSCREEN_NAV_BAR_MODE_HIDDEN(2),
        UNRECOGNIZED(-1);

        public static final int FULLSCREEN_NAV_BAR_MODE_HIDDEN_VALUE = 2;
        public static final int FULLSCREEN_NAV_BAR_MODE_TRANSPARENT_VALUE = 1;
        public static final int FULLSCREEN_NAV_BAR_MODE_UNSPECIFIED_VALUE = 0;
        private static final Internal.EnumLiteMap<FullscreenNavBarMode> internalValueMap = new C1052r0();
        private final int value;

        FullscreenNavBarMode(int i) {
            this.value = i;
        }

        public static FullscreenNavBarMode forNumber(int i) {
            if (i == 0) {
                return FULLSCREEN_NAV_BAR_MODE_UNSPECIFIED;
            }
            if (i == 1) {
                return FULLSCREEN_NAV_BAR_MODE_TRANSPARENT;
            }
            if (i != 2) {
                return null;
            }
            return FULLSCREEN_NAV_BAR_MODE_HIDDEN;
        }

        public static Internal.EnumLiteMap<FullscreenNavBarMode> internalGetValueMap() {
            return internalValueMap;
        }

        public static Internal.EnumVerifier internalGetVerifier() {
            return C1054s0.f15537a;
        }

        @Override // com.google.protobuf.Internal.EnumLite
        public final int getNumber() {
            if (this != UNRECOGNIZED) {
                return this.value;
            }
            C0950f.m10578i("Can't get the number of an unknown enum value.");
            return 0;
        }

        @Deprecated
        public static FullscreenNavBarMode valueOf(int i) {
            return forNumber(i);
        }
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public enum NativeStartMode implements Internal.EnumLite {
        NATIVE_START_MODE_UNSPECIFIED(0),
        NATIVE_START_MODE_DRY_RUN_ON_SHOW(1),
        NATIVE_START_MODE_DRY_RUN_ON_DISPLAY(2),
        NATIVE_START_MODE_ON_SHOW(3),
        NATIVE_START_MODE_ON_DISPLAY(4),
        UNRECOGNIZED(-1);

        public static final int NATIVE_START_MODE_DRY_RUN_ON_DISPLAY_VALUE = 2;
        public static final int NATIVE_START_MODE_DRY_RUN_ON_SHOW_VALUE = 1;
        public static final int NATIVE_START_MODE_ON_DISPLAY_VALUE = 4;
        public static final int NATIVE_START_MODE_ON_SHOW_VALUE = 3;
        public static final int NATIVE_START_MODE_UNSPECIFIED_VALUE = 0;
        private static final Internal.EnumLiteMap<NativeStartMode> internalValueMap = new C1056t0();
        private final int value;

        NativeStartMode(int i) {
            this.value = i;
        }

        public static NativeStartMode forNumber(int i) {
            if (i == 0) {
                return NATIVE_START_MODE_UNSPECIFIED;
            }
            if (i == 1) {
                return NATIVE_START_MODE_DRY_RUN_ON_SHOW;
            }
            if (i == 2) {
                return NATIVE_START_MODE_DRY_RUN_ON_DISPLAY;
            }
            if (i == 3) {
                return NATIVE_START_MODE_ON_SHOW;
            }
            if (i != 4) {
                return null;
            }
            return NATIVE_START_MODE_ON_DISPLAY;
        }

        public static Internal.EnumLiteMap<NativeStartMode> internalGetValueMap() {
            return internalValueMap;
        }

        public static Internal.EnumVerifier internalGetVerifier() {
            return C1058u0.f15539a;
        }

        @Override // com.google.protobuf.Internal.EnumLite
        public final int getNumber() {
            if (this != UNRECOGNIZED) {
                return this.value;
            }
            C0950f.m10578i("Can't get the number of an unknown enum value.");
            return 0;
        }

        @Deprecated
        public static NativeStartMode valueOf(int i) {
            return forNumber(i);
        }
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public enum PreShowWebViewStrategy implements Internal.EnumLite {
        PRE_SHOW_WEB_VIEW_STRATEGY_UNSPECIFIED(0),
        PRE_SHOW_WEB_VIEW_STRATEGY_EAGER(1),
        PRE_SHOW_WEB_VIEW_STRATEGY_POOL_ACQUIRE_AT_SHOW(2),
        PRE_SHOW_WEB_VIEW_STRATEGY_POOL_PRELOAD_ON_LOAD(3),
        UNRECOGNIZED(-1);

        public static final int PRE_SHOW_WEB_VIEW_STRATEGY_EAGER_VALUE = 1;
        public static final int PRE_SHOW_WEB_VIEW_STRATEGY_POOL_ACQUIRE_AT_SHOW_VALUE = 2;
        public static final int PRE_SHOW_WEB_VIEW_STRATEGY_POOL_PRELOAD_ON_LOAD_VALUE = 3;
        public static final int PRE_SHOW_WEB_VIEW_STRATEGY_UNSPECIFIED_VALUE = 0;
        private static final Internal.EnumLiteMap<PreShowWebViewStrategy> internalValueMap = new C1060v0();
        private final int value;

        PreShowWebViewStrategy(int i) {
            this.value = i;
        }

        public static PreShowWebViewStrategy forNumber(int i) {
            if (i == 0) {
                return PRE_SHOW_WEB_VIEW_STRATEGY_UNSPECIFIED;
            }
            if (i == 1) {
                return PRE_SHOW_WEB_VIEW_STRATEGY_EAGER;
            }
            if (i == 2) {
                return PRE_SHOW_WEB_VIEW_STRATEGY_POOL_ACQUIRE_AT_SHOW;
            }
            if (i != 3) {
                return null;
            }
            return PRE_SHOW_WEB_VIEW_STRATEGY_POOL_PRELOAD_ON_LOAD;
        }

        public static Internal.EnumLiteMap<PreShowWebViewStrategy> internalGetValueMap() {
            return internalValueMap;
        }

        public static Internal.EnumVerifier internalGetVerifier() {
            return C1062w0.f15541a;
        }

        @Override // com.google.protobuf.Internal.EnumLite
        public final int getNumber() {
            if (this != UNRECOGNIZED) {
                return this.value;
            }
            C0950f.m10578i("Can't get the number of an unknown enum value.");
            return 0;
        }

        @Deprecated
        public static PreShowWebViewStrategy valueOf(int i) {
            return forNumber(i);
        }
    }

    /* compiled from: r8-map-id-c19697ae3bae12b78a401547d6c4ae742ba54fa22df6d1590fb4771f8133b43b */
    public enum ShowCompletionState implements Internal.EnumLite {
        SHOW_COMPLETION_STATE_UNSPECIFIED(0),
        SHOW_COMPLETION_STATE_SKIPPED(1),
        SHOW_COMPLETION_STATE_COMPLETED(2),
        UNRECOGNIZED(-1);

        public static final int SHOW_COMPLETION_STATE_COMPLETED_VALUE = 2;
        public static final int SHOW_COMPLETION_STATE_SKIPPED_VALUE = 1;
        public static final int SHOW_COMPLETION_STATE_UNSPECIFIED_VALUE = 0;
        private static final Internal.EnumLiteMap<ShowCompletionState> internalValueMap = new C1064x0();
        private final int value;

        ShowCompletionState(int i) {
            this.value = i;
        }

        public static ShowCompletionState forNumber(int i) {
            if (i == 0) {
                return SHOW_COMPLETION_STATE_UNSPECIFIED;
            }
            if (i == 1) {
                return SHOW_COMPLETION_STATE_SKIPPED;
            }
            if (i != 2) {
                return null;
            }
            return SHOW_COMPLETION_STATE_COMPLETED;
        }

        public static Internal.EnumLiteMap<ShowCompletionState> internalGetValueMap() {
            return internalValueMap;
        }

        public static Internal.EnumVerifier internalGetVerifier() {
            return C1066y0.f15543a;
        }

        @Override // com.google.protobuf.Internal.EnumLite
        public final int getNumber() {
            if (this != UNRECOGNIZED) {
                return this.value;
            }
            C0950f.m10578i("Can't get the number of an unknown enum value.");
            return 0;
        }

        @Deprecated
        public static ShowCompletionState valueOf(int i) {
            return forNumber(i);
        }
    }

    public static void registerAllExtensions(ExtensionRegistryLite extensionRegistryLite) {
    }
}
